<?php 
 function transposeSciSequence($sciSequence, $numOfInterval)
 {
  $sciSequenceArray=explode(";", $sciSequence);
  
  foreach($sciSequenceArray as $sci)
  {
   $startNote=sci2startNote($sci);
   $sciCode=sci2sciCode($sci);
   $numOfStartNote=note2num($startNote);
   $newStartNote=num2note(($numOfStartNote+$numOfInterval)%12,$startNote);
   $newSci="$newStartNote $sciCode";
   $newSciSequenceArray[$num++]=$newSci;
  }
  return implode(";", $newSciSequenceArray);
 }
 
 function sciInSciSequence($sci, $sciSequence)
 {
  $retval=false;
  $sciSequenceArray=explode(";", $sciSequence);
  foreach($sciSequenceArray as $sciToCheck)
   if($sciToCheck==$sci)
    $retval=true;
  return $retval;
 }
 
 function getSubSciArray($sci,$numNoteMax)
 {
  //find all of the spellings with fewer than numNotes
  //for each spellingToCheck
  //find all of the modes of sci
  //for each mode check to see if all spellingToCheck elements are found
  $numNotes=sci2numNotes($sci);
  $spelling=sci2spelling($sci);
  $spellingArray=explode(",",$spelling);
  $startNote=sci2startNote($sci);
  $retArrayNum=0;
  $sql="select * from tblSciType where booPrefer=1 and numNote<$numNotes and numNote<$numNoteMax order by numNote, numOrdering";
  $resultArray=dbSelect($sql);
  //echo "$sql<br>";
  if(is_array($resultArray))
  {
   foreach($resultArray as $result)
   {
   	$spellingToCheck=$result['txtSpelling'];
   	$spellingToCheckArray=explode(",",$spellingToCheck);
   	//echo "spellingToCheck: $spellingToCheck<br>";
    $modeArray=getModeArray($spelling);

    //for each mode check to see if all spellingToCheck elements are found
    foreach($modeArray as $mode)
    {
     $modeSpelling = $mode[1];
     $modeAt=$mode[0];
     //echo "modeSpelling: ($modeAt) $modeSpelling<br>";
     $modeSpellingArray=explode(",", $modeSpelling);

     $allFound=true;
     foreach($spellingToCheckArray as $spellingToCheckElement)
     {
      $spellingToCheckElementFound=false;
      
      foreach($modeSpellingArray as $modeSpellingElement)
      {
       if($spellingToCheckElement==$modeSpellingElement)
       {
       	//echo "found! modeAt:$modeAt<br>";
       	$spellingToCheckElementFound=true;
       }
      }
      
      if(!$spellingToCheckElementFound)
       $allFound=false;
     }
     if($allFound)
     {
      $theNote=num2note(($note=sc2num($modeAt)+note2num($startNote))%12,$startNote);
      $theCode=convertToCodeIfPossible($spellingToCheck);
      //echo "all Found! $theNote $theCode / modeAt:$modeAt spelling:$spellingToCheck<br>";
      $retArray[$retArrayNum]="$theNote $theCode";
      $retArrayNum++;
     }
    }
   }
  }
  return $retArray;
 }

 function sci2numNotes($sci)
 {
  $spelling=sci2spelling($sci);
  $spellingArray=explode(",", $spelling);
  return count($spellingArray)+1;
 }
  
 function convertToCodeIfPossible($spelling)
 {
  $sql="select * from tblSciType where txtSpelling='$spelling'";
  $result=dbSelect($sql);
  if(count(result)>0 && $result[1]['txtCode']<>"")
   return $result[1]['txtCode'];
  else
   return $spelling;
 }

 function expandSciSequence($sciSequence)
 {
  $sciSequenceArray=explode(";", $sciSequence);
  
  foreach($sciSequenceArray as $sci)
  {
   $startNote=sci2startNote($sci);
   $numOfStartNote=note2num($startNote);
   //echo "now working with $sci ($numOfStartNote)<br>";
   $numOfCompleteSpellingOfSciArray=0;
   for($i=1;$i<=11;$i++)
   {
    $currentSciDegree=num2sc($i);
   	$numOfDegreeToCheck=($i+$numOfStartNote)%12;
    //echo "now checking $currentSciDegree ($numOfDegreeToCheck)<br>";
   	
    foreach($sciSequenceArray as $sciToCheck)
    {
     //echo "now checking sciToCheck $sciToCheck<br>";
     $sciToCheckStartNote=sci2startNote($sciToCheck);
     $numOfSciToCheckStartNote=note2num($sciToCheckStartNote);
     $sciToCheckSpelling="1,".sci2spelling($sciToCheck);
     $sciToCheckSpellingArray=explode(",",$sciToCheckSpelling);
     foreach($sciToCheckSpellingArray as $sciToCheckSpellingElement) 
     {
      $numOfSciToCheckSpellingElement = 
      ( sc2num($sciToCheckSpellingElement)
        + $numOfSciToCheckStartNote
        
      ) % 12; 
      //echo "now checking sciToCheckSpellingElement $sciToCheckSpellingElement ($numOfSciToCheckSpellingElement)<br>";
      if($numOfDegreeToCheck==$numOfSciToCheckSpellingElement)
      {
       //$completeSpellingOfSci=implode(",",$completeSpellingOfSciArray);
       $alreadyThere=false;
       if(is_array($completeSpellingOfSciArray))
        foreach($completeSpellingOfSciArray as $elementAlreadyThere)
        {
         //echo "currentSciDegree=$currentSciDegree elementAlreadyThere=$elementAlreadyThere<br>";
         if($currentSciDegree==$elementAlreadyThere)
         {
          //echo "true!<br>";
          $alreadyThere=true;
         }
        }
       if($alreadyThere==false)
       {
       	//echo "$currentSciDegree not already there (inside $completeSpellingOfSci)!<br>";
        $completeSpellingOfSciArray[$numOfCompleteSpellingOfSciArray]=
         $currentSciDegree;
        $numOfCompleteSpellingOfSciArray++;
       }
       ///echo "found $currentSciDegree in $sciToCheck<br>";
      }
     }    
    }
   } 
   $completeSpellingOfSci=implode(",",$completeSpellingOfSciArray);
   $sciCode=convertToCodeIfPossible($completeSpellingOfSci);
   $retArray[$retArrayNum]="$startNote $sciCode";
   $retArrayNum++;
  }
  return implode(";", $retArray);
 }


/*
  $sql="select * from tblSciType where txtSpelling='$spelling'";
  $result=dbSelect($sql);
  if(count(result)>0 && $result[1]['txtCode']<>"")
  {
   $code=$result[1]['txtCode'];
   echo "found!<br>";
   $returnval="$note $code";
  }
  else
  {
   $sciSequenceArray=explode(",", $sciSequence);
   $found=false;
   foreach($sciSequenceArray as $sci)
   {
   	$note=sci2startNote($sci);
    $modeArray=getModeArray($spelling);
    foreach($modeArray as $mode)
    {
     $modeAt=$mode[0];
     if(num2note(sc2num($modeAt),$note)==$note)
     {
      $modeSpelling=$mode[1];
      $sql="select * from tblSciType where txtSpelling='$modeSpelling'";
      $result=dbSelect($sql);
      if(count(result)>0 && $result[1]['txtCode']<>"")
      {
       $found=true;
       $code=$result[1]['txtCode'];
       echo "f2!<br>";
       $returnval="$note $code";
      }
     }
    }    
   }
   if(!$found)
    $returnval=getPreferredSci($note,$spelling);
  }
  return $returnval;
 }
*/
 function getPreferredSci($note, $spelling)
 {
  //echo "note: $note spelling: $spelling<br>";
  $result=dbSelect("select * from tblSciType where txtSpelling='$spelling'");
  $code=$result[1]['txtCode'];
  if($result[1]['booPrefer']=="1") 
   $returnval="$note $code";
  else
  {
   $modeArray=getModeArray($spelling);
   foreach ($modeArray as $modeNum => $thisMode) 
   {
    $modeSpelling = $thisMode[1];
    //echo "modeSpelling: $modeSpelling<br>";
    $result=dbSelect("select * from tblSciType where txtSpelling='$modeSpelling'");
    $modeCode=$result[1]['txtCode'];
    $modeAt=$thisMode[0];
    //echo "modeAt: $modeAt modeCode: $modeCode<br>";
    if($result[1]['booPrefer']=="1") 
     $returnval=num2note(sc2num($modeAt),$note)." $modeCode";
   }
  }
  return $returnval;
 }

 function sciSequence2sci($sciSequence)
 {
  $sciSequenceArray=explode(",", $sciSequence);
  $provisionalStartNote="";
  $num=0;
  for($i=1;$i<=12;$i++)
  {
   foreach($sciSequenceArray as $sci)
   {
   	$spelling=sci2spelling($sci);
   	$startNote=sci2startNote($sci);
   	$notes=spelling2notes($spelling,$startNote);
   	$noteArray=explode(",",$notes);
   	
   	if($provisionalStartNote=="") 
   	 $provisionalStartNote=$startNote;
   	
   	foreach($noteArray as $note)
   	{
   	 //what sciDegree is this note relative to the provisional note?
   	 if((note2num($note)+note2num($provisionalStartNote))%12==$i)
   	 {
   	  $found=false;
   	  if(is_array($provisionalSpellingArray))
       foreach ($provisionalSpellingArray as $provisionalSciDegree)
        if($provisionalSciDegree==num2sc($i))
         $found=true;
      if($found==false)
      {
   	   $provisionalSpellingArray[$num]=num2sc($i);
   	   $num++;
      }
   	 }
   	}
   }
  }
  $provisionalSpelling=implode(",", $provisionalSpellingArray);
//  echo "provisional StartNote: $provisionalStartNote<br>";
//  echo "provisional Spelling: $provisionalSpelling<br>";
  return getSequenceSci($provisionalStartNote, $provisionalSpelling, $sciSequence);
 }
 function spelling2numHalfStepsInRow($spelling)
 {
  if($spelling=="") $spelling="1";
  else $spelling="1,".$spelling;
  $spellingArray=explode(",", $spelling);
  $maxInARow=0;
  for($i=0;$i<=24;$i++)
  {
   $found=false;
   foreach ($spellingArray as $sciDegree)
   { 
    if(sc2num($sciDegree)==$i%12)
    { 
     $found=true;    	 
     $maxInThisSequence++;
    }
   }
   if($found) 
   {
    if($maxInThisSequence>$maxInARow)
     $maxInARow=$maxInThisSequence;
   }
   else $maxInThisSequence=0;
  }
  if($maxInARow>12) $maxInARow=12;  
  return $maxInARow;
 }

 function spelling2numSymForms($spelling)
 {
  //echo "$spelling<br>";
  $modeArray=getModeArray($spelling);

  foreach ($modeArray as $mode)
  {
   $symmetricalNum[$mode[1]]++;
  }
  $symmetricalNum[$spelling]++;
  $symmetricalFormNumber=0;
  foreach($symmetricalNum as $thes)
  {
   //echo $thes."<br>";
   if($thes>1)
   {
   //echo "sfn: $symmetricalFormNumber<br>"; 
   $symmetricalFormNumber++;
   }
  }  
  //echo "returning $symmetricalFormNumber<br>";
  return $symmetricalFormNumber;
 }

 //revise this to go from "1,b2,2" etc to "1,5,2" etc
 function spelling2numOrdering($spelling)
 {
  if($spelling=="") return 0;
  else
  {
   $spellingArray=explode(",", $spelling);
   $numOrdering=0;
   foreach ($spellingArray as $scNum => $sc)
   {
    $numOrdering+=pow(2,11-sc2num($sc));
    }
   return $numOrdering;
  }
 }
 
 //revise this to go from "1,b2,2" etc to "1,5,2" etc
 function numOrdering2spelling($numOrdering)
 {
  $spelling="";
  for($i=0;$i<=11;$i++)
  {
   if(($numOrdering/(pow(2,$i)))%2==1)
   {
    if($spelling=="") $spelling=num2sc(11-$i);
    else $spelling=num2sc(11-$i).",$spelling";
   }   
  }
  return $spelling;
 }

 function populateNumHalfStepsInRow()
 {
  $sql="select txtSpelling from tblSciType";
  $result=dbSelect($sql);
  if(is_array($result))
  {
   foreach($result as $sciTypeRecord)
   {
   	$spelling=$sciTypeRecord['txtSpelling'];
   	$numHalfStepsInRow=spelling2numHalfStepsInRow($spelling);
   	$sql="update tblSciType set numHalfStepsInRow=$numHalfStepsInRow where txtSpelling='$spelling'";
   	echo "sp:$spelling nif:$numHalfStepsInRow $sql<br>";
   	dbExecute($sql);
   }
  }
 }
 
 function populateTxtNumIntervalForm()
 {
  $sql="select txtSpelling from tblSciType";
  $result=dbSelect($sql);
  if(is_array($result))
  {
   foreach($result as $sciTypeRecord)
   {
   	$spelling=$sciTypeRecord['txtSpelling'];
   	$numIntervalForm=spelling2numIntervalForm($spelling);
   	$sql="update tblSciType set txtNumIntervalForm='$numIntervalForm' where txtSpelling='$spelling'";
   	echo "sp:$spelling nif:$numIntervalForm $sql<br>";
   	//dbExecute($sql);
   }
  }
 }

 function populateNumOrdering()
 {
  $sql="select txtSpelling from tblSciType";
  $result=dbSelect($sql);
  if(is_array($result))
  {
   foreach($result as $sciTypeRecord)
   {
   	$spelling=$sciTypeRecord['txtSpelling'];
   	$numOrdering=spelling2numOrdering($spelling);
   	$sql="update tblSciType set numOrdering='$numOrdering' where txtSpelling='$spelling'";
   	echo "sp:$spelling nif:$numIntervalForm $sql<br>";
   	dbExecute($sql);
   }
  }
 }

 function populateNumSymForms()
 {
  $sql="select txtSpelling from tblSciType";
  $result=dbSelect($sql);
  if(is_array($result))
  {
   foreach($result as $sciTypeRecord)
   {
   	$spelling=$sciTypeRecord['txtSpelling'];
   	$numSymForms=spelling2numSymForms($spelling);
   	$sql="update tblSciType set numSymForms='$numSymForms' where txtSpelling='$spelling'";
   	echo "sp:$spelling nif:$numSymForms $sql<br>";
   	dbExecute($sql);
   }
  }
 }
 
 function spelling2numIntervalForm($spelling)
 {
  $spellingArray=explode(",", $spelling);
  
  $previousNum="0";
  foreach($spellingArray as $spellingNum => $sc)
  {
   $scNum=sc2num($sc);
   $interval[$spellingNum]=$scNum-$previousNum;  
   $previousNum=$scNum;
  }
  $numIntervalForm=implode(" ", $interval);
  return $numIntervalForm;
 }

 function sci2spelling($sci)
 {
  $arrayFormOfSci=explode(" ", $sci);
  $sciCode=$arrayFormOfSci[1];
  //echo "sciCode: $sciCode<br>";
  $sql="SELECT txtSpelling from tblSciType where txtCode='$sciCode'";
  $result=dbSelect($sql);
  if(is_array($result))
  {
   //echo "spelling: ".$result[1]['txtSpelling']."<br>";
   return $result[1]['txtSpelling'];
  }
  else return $sci;
 }
 
 function sci2startNote($sci)
 {
  $arrayFormOfSci=explode(" ", $sci);
  //echo "afos: ".$arrayFormOfSci[0]."<br>";
  return $arrayFormOfSci[0];
 }
 function sci2sciCode($sci)
 {
  $arrayFormOfSci=explode(" ", $sci);
  //echo "afos: ".$arrayFormOfSci[0]."<br>";
  return $arrayFormOfSci[1];
 }

 function random_password($length) 
 {
  srand(date("s"));
  $possible_charactors = "abcdefghijklmnopqrstuvwxyz1234567890ABCDEFGHIJKLMNOPQRSTUVWXYZ";
  $string = "";
  while(strlen($string)<$length) 
  {
   $string .= substr
   (
    $possible_charactors, 
    rand()%(strlen($possible_charactors)),
    1
   );
  }
  return($string);
 }

 function boo2YN( $str ) 
 {
  return $str==1?"Yes":"No";
 }

 //$numSciElement is numerical form of sciElement
 //sciElement is "b2", etc
 function numSciElementToSpelling( $numSciElement ) 
 {
  if($numSciElement==1) $spelling="1";
  if($numSciElement==2) $spelling="b2";
  if($numSciElement==3) $spelling="2";
  if($numSciElement==4) $spelling="b3";
  if($numSciElement==5) $spelling="3";
  if($numSciElement==6) $spelling="4";
  if($numSciElement==7) $spelling="b5";
  if($numSciElement==8) $spelling="5";
  if($numSciElement==9) $spelling="b6";
  if($numSciElement==10) $spelling="6";
  if($numSciElement==11) $spelling="b7";
  if($numSciElement==12) $spelling="7";
 return $spelling;
 }

 function spellingToNote( $spelling ) 
 {
  if($spelling="1") $note=1;
  if($spelling="b2") $note=2;
  if($spelling="2") $note=3;
  if($spelling="b3") $note=4;
  if($spelling="3") $note=5;
  if($spelling="4") $note=6;
  if($spelling="b5") $note=7;
  if($spelling="5") $note=8;
  if($spelling="b6") $note=9;
  if($spelling="6") $note=10;
  if($spelling="b7") $note=11;
  if($spelling="7") $note=12;
  return $note;
 }

 function getModeOffset($spelling, $modeNum) 
 {
  echo "called get Mode offset($spelling, $modeNum)";
  $currentOffset= 1;
  for($i=1;$i<=$modeNum;$i++) {
   $currentOffset=strpos(substr($spelling,$currentOffset), "1")+1;
   echo "substr:".substr($spelling,$currentOffset)."<br>";
   echo "Currentoffset: ".$currentOffset."<br>";
  }
  echo "returning $currentOffset<br>";
  return $currentOffset;
 }


 function foundInNoteAndCodeArray($noteAndCode, $preferredModes)
 {
  $found=false;
  if(is_array($preferredModes))
   foreach($preferredModes as $preferredModeNum => $currentPreferredMode)
    if($currentPreferredMode==$noteAndCode) 
     $found=$preferredModeNum;
  return $found;
 }


 function getPreferredCode($spelling)
 {
  $modeArray=getModeArray($spelling);
  $returnval="";
  foreach ($modeArray as $modeNum => $thisMode) 
  {
   $modeSpelling = $thisMode[1];
   if($modeSpelling<>$spelling)
   {
    $modeValues=getScaleFromSpelling($modeSpelling); 
    $modeScaleArray=getScaleFromSpelling($modeSpelling);
    $modeCode=$modeScaleArray['txtCode'];
    $modeAt=$thisMode[0];
    if($modeValues['booPrefer']=="1") 
    { 
     $returnval="mode $modeAt of $modeCode";
    }
   }
  }
  if($returnval=="")
  {
   $scaleArray=getScaleFromSpelling($spelling);  
   $scaleCode=$scaleArray['txtCode'];
   $returnval="$scaleCode";
  }
  if($returnval=="")
  {
   $returnval="{";
   foreach ($modeArray as $modeNum => $thisMode) 
   {
    $modeSpelling = $thisMode[1];
    if($returnval=="{")
     $returnval.=" $modeSpelling";  
    else $returnval.=" / $modeSpelling";
   }
   $returnval.=" }";
  }
  return $returnval;
 }

function getSpellingAndNoteArrayFromSourceAndSourceType($source, $sourceType, $note, $strings)
{
  if($sourceType=="spelling") $spelling = $source;
  if($sourceType=="chordPosition")
  {
  	$spellingAndNoteArray=chordPo2spellingAndNoteArray($source,$strings);
  }
  return $spellingAndNoteArray;
}
//----------------------------------------------------note2num
function num2note($num,$referenceNote)
{
 $sharp=strpos($referenceNote, "#");
 $flat=strpos($referenceNote, "b");
 if($num%12==0) $outNote="C";
 if($num%12==1 && $sharp) $outNote="C#";
 if($num%12==1 && !$sharp) $outNote="Db";
 if($num%12==2) $outNote="D";
 if($num%12==3 && $sharp) $outNote="D#";
 if($num%12==3 && !$sharp) $outNote="Eb";
 if($num%12==4) $outNote="E";
 if($num%12==5) $outNote="F";
 if($num%12==6 && $sharp) $outNote="F#";
 if($num%12==6 && !$sharp) $outNote="Gb";
 if($num%12==7) $outNote="G";
 if($num%12==8 && $sharp) $outNote="G#";
 if($num%12==8 && !$sharp) $outNote="Ab";
 if($num%12==9) $outNote="A";
 if($num%12==10 && $sharp) $outNote="A#";
 if($num%12==10 && !$sharp) $outNote="Bb";
 if($num%12==11) $outNote="B";
 return $outNote;
}
//----------------------------------------------------note2num
function note2num($note)
{
 if($note=="C") $outNum=0;
 if($note=="C#") $outNum=1;
 if($note=="Db") $outNum=1;
 if($note=="D") $outNum=2;
 if($note=="D#") $outNum=3;
 if($note=="Eb") $outNum=3;
 if($note=="E") $outNum=4;
 if($note=="F") $outNum=5;
 if($note=="F#") $outNum=6;
 if($note=="Gb") $outNum=6;
 if($note=="G") $outNum=7;
 if($note=="G#") $outNum=8;
 if($note=="Ab") $outNum=8;
 if($note=="A") $outNum=9;
 if($note=="A#") $outNum=10;
 if($note=="Bb") $outNum=10;
 if($note=="B") $outNum=11;
 return $outNum;

}
//----------------------------------------------------sc2note
function sc2note($sc, $startNote)
{
 $noteNum = note2num($startNote);
 $scNum = sc2num($sc);
 $newNum = $noteNum + $scNum;
 $outNote=num2note($newNum,$startNote);
 return $outNote;
}
//----------------------------------------------------spelling2notes
function spelling2notes($spelling, $startNote)
{
 $spelling="1,".$spelling;
 $outNotes="";
 foreach (explode(",", $spelling) as $scNum => $sc) 
 {
   if($outNotes != "") $outNotes.=","; 
   $outNotes.=sc2note($sc,$startNote);
 }
 return $outNotes;
}
//----------------------------------------------------num2sc
function num2sc($inNum)
{
if($inNum=="1" || $inNum%12==1) $outSc="b2";
if($inNum=="2" || $inNum%12==2) $outSc="2";
if($inNum=="3" || $inNum%12==3) $outSc="b3";
if($inNum=="4" || $inNum%12==4) $outSc="3";
if($inNum=="5" || $inNum%12==5) $outSc="4";
if($inNum=="6" || $inNum%12==6) $outSc="b5";
if($inNum=="7" || $inNum%12==7) $outSc="5";
if($inNum=="8" || $inNum%12==8) $outSc="b6";
if($inNum=="9" || $inNum%12==9) $outSc="6";
if($inNum=="10" || $inNum%12==10) $outSc="b7";
if($inNum=="11" || $inNum%12==11) $outSc="7";
if($inNum=="0" || $inNum%12==0) $outSc="1";
return $outSc;
}
//----------------------------------------------------sc2num
function sc2num($inSc)
{
if($inSc=="1") $outNum="0";
if($inSc=="b2") $outNum="1";
if($inSc=="2") $outNum="2";
if($inSc=="b3") $outNum="3";
if($inSc=="3") $outNum="4";
if($inSc=="4") $outNum="5";
if($inSc=="b5") $outNum="6";
if($inSc=="5") $outNum="7";
if($inSc=="b6") $outNum="8";
if($inSc=="6") $outNum="9";
if($inSc=="b7") $outNum="10";
if($inSc=="7") $outNum="11";
return $outNum;
}

//----------------------------------------------------getRelativeSpelling
function getRelativeSpelling($txtSpelling, $startSc)
{
 $txtSpelling="1,".$txtSpelling;
 $outSpelling="";
 foreach (explode(",", $txtSpelling) as $scNum => $sc) 
 {
   if($outSpelling != "") $outSpelling.=","; 
   $outSpelling.=num2sc
   (
    (
     sc2num($sc)+sc2num($startSc)
    )%12
   );
 }
 return $outSpelling;

}
//----------------------------------------------------getSuperScaleArray
function getSuperScaleArray($txtSpelling, $numNote, $startSc, $referenceNote)
{

 for( $scNum=0; $scNum<12; $scNum++)
 {
  $relSpelling=getRelativeSpelling($txtSpelling, 
    num2sc( (sc2num($startSc)+1)%12 ));
  $sql="select * from tblSciType where numNote = 7 ";
  //numNote = ".($numNote+1);
  
  $relArray=explode(",",  $relSpelling);
  
  foreach ($relArray as $key => $value) 
  {
    $newSc= num2Sc((sc2num($value)+$scNum+sc2Num($relArray[0])+10)%12);
  
    if($newSc != "1")
  
     $sql.=" and (txtSpelling regexp '^$newSc' or txtSpelling regexp ',$newSc')";
  }
  
  $sql.=" ORDER BY numNote, txtSpelling";
  
  //echo $sql."<br>";  
  $superScaleArray="";
  
  $result = mysql_query($sql) or die("Invalid query: ".mysql_error()." sql: ".$sql);
  $num_rows = mysql_num_rows($result);
  if( $num_rows > 0 ) 
  {
    $fields = mysql_num_fields($result);
    for( $j=1; $row=mysql_fetch_array($result); $j++) {
      for( $i=0; $i<$fields; $i++)  {
        $name=mysql_field_name($result, $i);
        $superScaleArray[$j][$name] = $row[$name];
      } //end for
    } //end while
   }
  if(is_array($superScaleArray))
   foreach ($superScaleArray as $scaleNum => $scale) 
   {
    echo "<br>Superscale ".num2sc($scNum).": <b>";
    if($referenceNote!="")
    {
      $relArray=explode(",", getRelativeSpelling($scale['txtSpelling'],$relSc));
      $firstNote = $relArray[0];
      $superNote = num2note(( note2num($referenceNote)+sc2num($firstNote) ) %12 , $referenceNote);
      $notes = spelling2notes($scale['txtSpelling'], $superNote);
      echo $superNote." ";
     }
    echo $scale['txtCode'].", </b>";

    if($referenceNote!="")
     echo " notes:".$notes;
    echo " abs:".$scale['txtSpelling'];
    //echo " scnum: ".$scNum;
    $relSc=num2sc(sc2num($startSc)+12-$scNum);
    //echo " relsc: ".$relSc;
    echo " rel:".getRelativeSpelling($scale['txtSpelling'],$relSc);
    echo " (";
    if($scale['txtName'] <> $scale['txtCode'])
    {
     echo $scale['txtName'];
     if($scale['txtAltNames'] <> "")
      echo ", ";
    }
    echo $scale['txtAltNames'].") ";
   }
 }

}
function getSpellingCount($spelling)
{
 return count(explode(",", $spelling))+1;
}

function noteAndSpellingInNoteAndSpelling($subscaleStartNote,$subscaleSpelling,$startNote,$spelling)
{
 //echo "noteAndSpellingInNoteAndSpelling($subscaleStartNote,$subscaleSpelling,$startNote,$spelling)<br>";
 $spellingArray=explode(",", $spelling);
 $subscaleSpellingArray=explode(",", $subscaleSpelling);
 $notes = spelling2notes($spelling, $startNote);
 $notesArray = explode(",", $notes);
 $subscaleNotes=spelling2notes($subscaleSpelling, $subscaleStartNote);
 $subscaleNotesArray=explode(",", $subscaleNotes);

 $allSubscaleNotesAreFound = true;

 foreach ($subscaleNotesArray as $subscaleNoteNum => $subscaleNote)
 {
  //echo " checking subscalenote: $subscaleNote<br>";
  $subscaleNoteIsFound=false;

  foreach ($notesArray as $noteNum => $note)
  {
   if($subscaleNote == $note) 
    $subscaleNoteIsFound = true;
   //echo " subscale note is found!<br>";
  }
  //echo "  subscalenote: $subscaleNote is found? $subscaleNoteIsFound<br>";
      
  if($subscaleNoteIsFound == false) 
   $allSubscaleNotesAreFound =false;
 }
 //echo "allSubscaleNotesAreFound: $allSubscaleNotesAreFound<br>";
 return $allSubscaleNotesAreFound;
}
function getSubScales($referenceNote, $spelling)
{
 $allNotes="C,G,D,A,E,B,Gb,Db,Ab,Eb,Bb,F";
 $allNotesArray = explode(",", $allNotes);
 $subscaleNum=0;
 $spellingArray=explode(",", $spelling);
 $numNotes=count($spellingArray)+1;
 
 $sql="select * from tblSciType WHERE booPrefer=1 and numNote < $numNotes order by numNote";

 $result = mysql_query($sql) or die("Invalid query: ".mysql_error()." sql: ".$sql);
 $num_rows = mysql_num_rows($result);
 if( $num_rows > 0 ) 
 {
  $fields = mysql_num_fields($result);
  for( $j=1; $row=mysql_fetch_array($result); $j++) 
  {
   for( $i=0; $i<$fields; $i++)  
   {
    $name=mysql_field_name($result, $i);
    $subScaleArray[$j][$name] = $row[$name];
   } //end for
  } //end while
 }
 if(is_array($subScaleArray))
 {
  foreach ($allNotesArray as $subscaleNoteNum => $subscaleNote) 
  {
   foreach($subScaleArray as $subScaleArrayNum => $subScale)
   {
    $subscaleSpelling=$subScale['txtSpelling'];
    $subscaleCode=$subScale['txtCode'];
    if(noteAndSpellingInNoteAndSpelling($subscaleNote,$subscaleSpelling,$referenceNote,$spelling))
    {
     $subscales[$subscaleNum]=$subscaleNote." ".$subscaleCode;
     $subscaleNum++;
    }
   }
  }
 }
 return $subscales;
}

function getSuperScales($referenceNote, $spelling)
{
 $allNotes="C,G,D,A,E,B,Gb,Db,Ab,Eb,Bb,F";
 $allNotesArray = explode(",", $allNotes);
 $superscaleNum=0;
 $spellingArray=explode(",", $spelling);
 $numNotes=count($spellingArray)+1;
 
 $sql="select * from tblSciType WHERE booPrefer=1 and numNote > $numNotes and numNote < 12 order by numNote";

 $result = mysql_query($sql) or die("Invalid query: ".mysql_error()." sql: ".$sql);
 $num_rows = mysql_num_rows($result);
 if( $num_rows > 0 ) 
 {
  $fields = mysql_num_fields($result);
  for( $j=1; $row=mysql_fetch_array($result); $j++) 
  {
   for( $i=0; $i<$fields; $i++)  
   {
    $name=mysql_field_name($result, $i);
    $superscaleArray[$j][$name] = $row[$name];
   } //end for
  } //end while
 }
 if(is_array($superscaleArray))
 {
  foreach ($allNotesArray as $superscaleNoteNum => $superscaleNote) 
  {
   foreach($superscaleArray as $superscaleArrayNum => $superscale)
   {
    $superscaleSpelling=$superscale['txtSpelling'];
    $superscaleCode=$superscale['txtCode'];
    if(noteAndSpellingInNoteAndSpelling($referenceNote,$spelling,$superscaleNote,$superscaleSpelling))
    {
     $superscales[$superscaleNum]=$superscaleNote." ".$superscaleCode;
     $superscaleNum++;
    }
   }
  }
 }
 return $superscales;
}

//
function showOrganizedSubScales($spelling, $referenceNote)
{
 $outScale="";
 $outScaleNum=0;
 $numStrings=4; //fix this later!
 $allNotes="C,Db,D,Eb,E,F,Gb,G,Ab,A,Bb,B";
 $allNotesArray = explode(",", $allNotes);
 $spellingArray = explode(",", $spelling);
 $notes = spelling2notes($spelling, $referenceNote);
 $notesArray = explode(",", $notes);
 
 for ($numNote = 2; $numNote< count($spellingArray)+1; $numNote++)
 {
  $sql="select * from tblSciType WHERE numNote = $numNote and booPrefer=1 order by numNote";

  $result = mysql_query($sql) or die("Invalid query: ".mysql_error()." sql: ".$sql);
  $num_rows = mysql_num_rows($result);
  if( $num_rows > 0 ) 
  {
   $fields = mysql_num_fields($result);
   for( $j=1; $row=mysql_fetch_array($result); $j++) 
   {
    for( $i=0; $i<$fields; $i++)  
    {
     $name=mysql_field_name($result, $i);
     $subScaleArray[$j][$name] = $row[$name];
    } //end for
   } //end while
  }
  if(is_array($subScaleArray))
  {
   foreach($subScaleArray as $subScaleArrayNum => $subScale)
   {
    $subScaleSpelling=$subScale['txtSpelling'];
    $subScaleCode=$subScale['txtCode'];
    $subScaleOutput="";

    foreach ($allNotesArray as $startNoteNum => $startNote) 
    {
     //echo "subscale: $startNote $subScaleName<br>";
     $subScaleNotes=spelling2notes($subScaleSpelling, $startNote);
     //echo " $subScaleNotes<br>";
     $subScaleNotesArray=explode(",", $subScaleNotes);
  
     $allSubScaleNotesAreFound = true;

     foreach ($subScaleNotesArray as $subScaleNoteNum => $subScaleNote)
     {
      //echo " checking subscalenote: $subScaleNote<br>";
      $subScaleNoteIsFound=false;

      foreach ($notesArray as $noteNum => $note)
      {
       if($subScaleNote == $note) 
        $subScaleNoteIsFound = true;
        //echo " subscale note is found!<br>";
      }
      //echo "  subscalenote: $subScaleNote is found? $subScaleNoteIsFound<br>";
      
      if($subScaleNoteIsFound == false) 
       $allSubScaleNotesAreFound =false;
     }
     if($allSubScaleNotesAreFound)
     {
      //echo " all subScaleNotes are found! adding startnote: $startNote<br>";

      if($referenceNote=="") 
      {
       $sc=num2sc(note2num($startNote));
       if($subScaleOutput=="")
        $subScaleOutput = " $subScaleCode:$sc";
       else
        $subScaleOutput .= ",$sc";       
      }
      else
      {
       if($subScaleOutput=="")
        $subScaleOutput = " $subScaleCode:$startNote";
       else
        $subScaleOutput .= ",$startNote";
      }
      if(getSpellingCount($subScaleSpelling)<$numStrings)
      {
       $outScale[$outScaleNum]=$subScale;
       $outScale[$outScaleNum]['startNote']=$startNote;
       $outScaleNum++;
      }
     }
    }
    if($subScaleOutput !="") 
     echo "$subScaleOutput;"; 
   }
  }
 } 
 return $outScale;
}

function showOrganizedSuperScales($spelling, $referenceNote)
{
 $outScale="";
 $outScaleNum=0;
 $numStrings=4; //fix this later!
 $allNotes="C,Db,D,Eb,E,F,Gb,G,Ab,A,Bb,B";
 $allNotesArray = explode(",", $allNotes);
 $spellingArray = explode(",", $spelling);
 $notes = spelling2notes($spelling, $referenceNote);
 $notesArray = explode(",", $notes);
 
 $minNum= count($spellingArray)+2;
  $sql="select * from tblSciType WHERE numNote >= $minNum and numNote < 12 and booPrefer=1 order by numNote";
//echo "<br>$sql<br>";
  $result = mysql_query($sql) or die("Invalid query: ".mysql_error()." sql: ".$sql);
  $num_rows = mysql_num_rows($result);
  if( $num_rows > 0 ) 
  {
   $fields = mysql_num_fields($result);
   for( $j=1; $row=mysql_fetch_array($result); $j++) 
   {
    for( $i=0; $i<$fields; $i++)  
    {
     $name=mysql_field_name($result, $i);
     $superScaleArray[$j][$name] = $row[$name];
    } //end for
   } //end while
  }
  if(is_array($superScaleArray))
  {
   foreach($superScaleArray as $superScaleArrayNum => $superScale)
   {
    $superScaleSpelling=$superScale['txtSpelling'];
    $superScaleCode=$superScale['txtCode'];
    $superScaleOutput="";

    foreach ($allNotesArray as $startNoteNum => $startNote) 
    {
     //echo "superscale: $startNote $superScaleCode<br>";
     $superScaleNotes=spelling2notes($superScaleSpelling, $startNote);
     //echo " $superScaleNotes<br>";
     $superScaleNotesArray=explode(",", $superScaleNotes);
  
     $allNotesAreFoundInSuperScale = true;

     foreach ($notesArray as $noteNum => $note)
     {
      //echo " checking note: $note<br>";
      $noteIsFoundInSuperScale=false;

      foreach ($superScaleNotesArray as $superScaleNoteNum => $superScaleNote)
      {
       if($superScaleNote == $note) 
        $noteIsFoundInSuperScale = true;
        //echo " note is found in superscale!<br>";
      }
      //echo "  note: $note is found? $noteIsFoundInSuperScale<br>";
      
      if($noteIsFoundInSuperScale == false) 
       $allNotesAreFoundInSuperScale =false;
     }
     if($allNotesAreFoundInSuperScale)
     {
      //echo " all notes are found! adding startnote: $startNote<br>";

      if($referenceNote=="")
      {
       $sc=num2sc(note2num($startNote));
       if($superScaleOutput=="")
        $superScaleOutput = " $superScaleCode:$sc";
       else
        $superScaleOutput .= ",$sc";
      }
      else
      {
       if($superScaleOutput=="")
        $superScaleOutput = " $superScaleCode:$startNote";
       else
        $superScaleOutput .= ",$startNote";
      }
      if(getSpellingCount($superScaleSpelling)<$numStrings)
      {
       $outScale[$outScaleNum]=$superScale;
       $outScale[$outScaleNum]['startNote']=$startNote;
       $outScaleNum++;
      }
     }
    }
    if($superScaleOutput !="") 
     echo "$superScaleOutput;"; 
   }
  }
 return $outScale;
}

function showOrganizedModes($spelling, $referenceNote)
{
 $outScale="";
 $outScaleNum=0;
 $numStrings=4; //fix this later!
 $allNotes="C,Db,D,Eb,E,F,Gb,G,Ab,A,Bb,B";
 $allNotesArray = explode(",", $allNotes);
 $spellingArray = explode(",", $spelling);
 $notes = spelling2notes($spelling, $referenceNote);
 $notesArray = explode(",", $notes);
 
 for ($numNote=count($spellingArray)+1; $numNote== count($spellingArray)+1; $numNote++)
 {
  $sql="select * from tblSciType WHERE numNote = $numNote";

  $result = mysql_query($sql) or die("Invalid query: ".mysql_error()." sql: ".$sql);
  $num_rows = mysql_num_rows($result);
  if( $num_rows > 0 ) 
  {
   $fields = mysql_num_fields($result);
   for( $j=1; $row=mysql_fetch_array($result); $j++) 
   {
    for( $i=0; $i<$fields; $i++)  
    {
     $name=mysql_field_name($result, $i);
     $subScaleArray[$j][$name] = $row[$name];
    } //end for
   } //end while
  }
  if(is_array($subScaleArray))
  {
   foreach($subScaleArray as $subScaleArrayNum => $subScale)
   {
    $subScaleSpelling=$subScale['txtSpelling'];
    $subScaleCode=$subScale['txtCode'];
    $subScaleOutput="";

    foreach ($allNotesArray as $startNoteNum => $startNote) 
    {
     //echo "subscale: $startNote $subScaleName<br>";
     $subScaleNotes=spelling2notes($subScaleSpelling, $startNote);
     //echo " $subScaleNotes<br>";
     $subScaleNotesArray=explode(",", $subScaleNotes);
  
     $allSubScaleNotesAreFound = true;

     foreach ($subScaleNotesArray as $subScaleNoteNum => $subScaleNote)
     {
      //echo " checking subscalenote: $subScaleNote<br>";
      $subScaleNoteIsFound=false;

      foreach ($notesArray as $noteNum => $note)
      {
       if($subScaleNote == $note) 
        $subScaleNoteIsFound = true;
        //echo " subscale note is found!<br>";
      }
      //echo "  subscalenote: $subScaleNote is found? $subScaleNoteIsFound<br>";
      
      if($subScaleNoteIsFound == false) 
       $allSubScaleNotesAreFound =false;
     }
     if($allSubScaleNotesAreFound)
     {
      //echo " all subScaleNotes are found! adding startnote: $startNote<br>";
      if($subScaleOutput=="")
       $subScaleOutput = " $subScaleCode:$startNote";
      else
       $subScaleOutput .= ",$startNote";
      if(getSpellingCount($subScaleSpelling)<$numStrings)
      {
       $outScale[$outScaleNum]=$subScale;
       $outScale[$outScaleNum]['startNote']=$startNote;
       $outScaleNum++;
      }
     }
    }
    if($subScaleOutput !="") 
     echo "$subScaleOutput;"; 
   }
  }
 } 
 return $outScale;
}

//----------------------------------------------------getSubScaleArray
function getSubScaleArray($txtSpelling, $startSc, $referenceNote,$strings,$totalFrets,$nutPos,$fretSpan)
{
 $allScs="b2,2,b3,3,4,b5,5,b6,6,b7,7";
 $scsNotInSpelling="";
 foreach (explode(",",  $allScs) as $key => $value) 
 {
  if(!in_array($value, explode(",",$txtSpelling)))
  {
    if( $scsNotInSpelling=="")
     $scsNotInSpelling=$value;
    else
     $scsNotInSpelling.=",".$value;    
  }
 }

 $sql="select * from tblSciType where numNote <= ".count(explode(",",$txtSpelling));
 foreach (explode(",",  $scsNotInSpelling) as $key => $value) 
 {
   $sql.=" and txtSpelling not regexp '^$value' and txtSpelling not regexp ',$value' ";
 }
 $sql.=" order by numNote, txtSpelling";

echo $sql;
  $result = mysql_query($sql) or die("Invalid query: ".mysql_error()." sql: ".$sql);
  $num_rows = mysql_num_rows($result);
  if( $num_rows > 0 ) 
  {
    $fields = mysql_num_fields($result);
    for( $j=1; $row=mysql_fetch_array($result); $j++) {
      for( $i=0; $i<$fields; $i++)  {
        $name=mysql_field_name($result, $i);
        $subScaleArray[$j][$name] = $row[$name];
      } //end for
    } //end while
   }
  if(is_array($subScaleArray))
  {

    echo "<ul>";
  
   foreach ($subScaleArray as $scaleNum => $scale) 
   {
    echo "<li>";
    if($referenceNote!="")
     echo "<a href=\"intervals2scs.php?note=$referenceNote&intervals=".$scale['txtSpelling']."&nutPos=$nutPos&strings=$strings&frets=$totalFrets&fretSpan=$fretSpan&submit=\">".$referenceNote;
    else
      echo "<a href=\"\">";
    echo $scale['txtCode']."</a>, </b> ";

    if($referenceNote!="")
     echo " notes: ".spelling2notes($scale['txtSpelling'],$referenceNote);
    echo " abs:".$scale['txtSpelling'];
    echo " rel:".getRelativeSpelling($scale['txtSpelling'],$startSc);
    echo " (";
    if($scale['txtName'] <> $scale['txtCode'])
    {
     echo $scale['txtName'];
     if($scale['txtAltNames'] <> "")
      echo ", ";
    }
    echo $scale['txtAltNames'].") "; 

    //displayFretBoard($strings,$totalFrets,$nutPos, $scale['txtSpelling'], $referenceNote, true,"");

     //discoverChordPos($strings, $totalFrets, $fretSpan, $nutPos, $scale['txtSpelling'], $referenceNote);

    echo "</li>";
   }
   echo "</ul>";
  
  }
}


//------------------------------------------------getScaleArrayFromSpelling
function getScaleFromSpelling($txtSpelling)
{
  $sql ="SELECT * FROM tblSciType where txtSpelling='$txtSpelling' ORDER BY numNote"; 

  //echo $sql;
  $result = mysql_query($sql) or die("Invalid query: ".mysql_error()." sql: ".$sql);
  $num_rows = mysql_num_rows($result);
  if( $num_rows > 0 ) 
  {
    $fields = mysql_num_fields($result);
    for( $j=1; $row=mysql_fetch_array($result); $j++) {
      for( $i=0; $i<$fields; $i++)  {
        $name=mysql_field_name($result, $i);
        $scaleArray[$j][$name] = $row[$name];
      } //end for
    } //end while
   }
return $scaleArray[1];
}
function displayModeArray($modeArray,$spelling,$code,$referenceNote,$strings,$totalFrets,$nutPos,$fretSpan,$chordNumber)
{
  if(is_array($modeArray))
  {
    echo "<ul>";
    foreach ($modeArray as $modeNum => $thisMode )
    {
      echo "<li>";
      if($referenceNote!="")
        echo $referenceNote." ";
      echo "$code Mode ".$thisMode[0].": ";

      if($referenceNote!="")
        $modeNote=num2note(note2num($referenceNote)+sc2num($thisMode[0]),$referenceNote);
      
      $outMSc = $thisMode[1];
      $scaleArray=getScaleArrayFromSpelling($outMSc);
      if(is_array($scaleArray))
        foreach ($scaleArray as $scaleNum => $scale) 
        {
          echo "<a href=\"test.php?sourceType=spelling&note=$modeNote&source=$thisMode[1]&nutPos=$nutPos&strings=$strings&frets=$totalFrets&fretSpan=$fretSpan&chordNumber=$chordNumber\">$modeNote ";
          echo $scale['txtCode']."</a>, </b>";
        }

      if($referenceNote!="")
        echo "notes: ".spelling2notes($outMSc,$modeNote);
      echo " spelling:".$outMSc;
      echo " relativeSpelling: ".getRelativeSpelling($outMSc,$thisMode[0]);
      if(is_array($scaleArray))
        foreach ($scaleArray as $scaleNum => $scale) 
        {
          echo " (";
          if($scale['txtName'] <> $scale['txtCode'])
          {
            echo $scale['txtName'];
            if($scale['txtAltNames'] <> "")
              echo ", ";
          }
          echo $scale['txtAltNames'].") ";
        }
//        getSubScaleArray($outMSc, $thisMode[0], $modeNote,$strings,$totalFrets,$nutPos,$fretSpan);
      echo "</li>";
    } //close foreach loop
    echo "</ul>";
  }
}

//--------------------------------------------------------getModeArray
 function getModeArray($spelling)
 {
  $realModeArray[0][0]="1";
  $realModeArray[0][1]=$spelling;
  
  $spellingWithOne = "1,".$spelling;
  $numNotes=substr_count($spellingWithOne, ",")+1;
  $realModeNum=1;
  for( $thisMode=1; $thisMode<$numNotes; $thisMode++)
  {
   foreach (explode(",", $spellingWithOne) as $key => $value) 
   {
    if($key==0) $thisModeStartNum = sc2num($value);
    $modeArray[$thisMode][($thisMode+$key)%$numNotes]=$value;
   }
  }

  $outMSc = "";
  for( $thisMode=$numNotes-1; $thisMode>0; $thisMode--)
  {
   $outMSc = "";
   $startNum = sc2num($modeArray[$thisMode][0]);
   for( $thisSc=0; $thisSc < $numNotes; $thisSc++ )
   {
    if( $thisSc >= 2 ) 
      $outMSc.=",";
           
    if( $thisSc >= 1 ) 
    {
      $outMSc .= num2sc
      (
        (
          sc2num($modeArray[$thisMode][$thisSc]) + 12 - $startNum
        )%12
      );
   }
  }
  $realModeArray[$realModeNum][0]=$modeArray[$thisMode][0];
  $realModeArray[$realModeNum][1]=$outMSc;
  $realModeNum++;
  
 }
 return $realModeArray;
}
//-------------------------------------------------------------intervals2scs
function intervals2scs($inString)
{
  $outString="";
  $runningTotal=0;
  foreach (explode(" ", $inString) as $key => $value) 
  {
    $runningTotal+=$value;
    if($outString=="") $outString=num2sc($runningTotal);
    else $outString.=",".num2sc($runningTotal);
  }
  return $outString;
}

?>
