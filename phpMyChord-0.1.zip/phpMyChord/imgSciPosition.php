<?php 
 set_time_limit(20000);
 include_once("config.php");
 include_once("libDatabase.php");
 include_once("libGeneral.php");
 include_once("libGraphics.php");
 include_once("libString.php");
 connect();
 header("Content-type: image/x-png");

 $sciPosition=implode(",", explode("|", $_GET['sciPosition']));
 $tuning=implode(",", explode("|", $_GET['tuning']));
 $tuningArray=explode(",", $tuning);
 $sciPositionArray=explode(",", $sciPosition);

 if(isset($_GET['minFrets']))
  $minFrets=$_GET['minFrets']-1;
 else
  $minFrets=2;

 $lowestFret=getLowestFret($sciPosition);
 $highestFret=getHighestFret($sciPosition);
 
 $diff=$highestFret-$lowestFret;
 if($diff>$minFrets) $minFrets=$diff;
 if($diff<$minFrets && $lowestFret>1)
 { 	
  $startFret=$lowestFret-($minFrets-$diff);
 } else
  $startFret=$lowestFret;
 
 if($startFret<1) $startFret=1;
 $endFret=$startFret+$minFrets;

 $imgWidth=20*(count($tuningArray)+1);
 $imgHeight=20*($minFrets+3);

 $image=imagecreatetruecolor($imgWidth, $imgHeight);

 $colorWhite=imagecolorallocatealpha($image, 255, 255, 255,0);
 $colorBlack=imagecolorallocatealpha($image, 0, 0, 0,0);

 imagefilledrectangle ($image, 0, 0, $imgWidth, $imgHeight, $colorWhite);

 $imageSize=8;

 $notes=sciPosition2Notes($sciPosition, "C", $tuning);

 $imFileName="images".chr(47)."lowerLinew.png";  
  //echo "<img height=$imageSize width=$imageSize src=\"$imFileName\">";  

 $im=LoadPNG($imFileName);
 imagecopy ( $image, $im, 0, 0, 0, 0, 20, 20);
 
 foreach (explode(",",$notes) as $noteNum => $theNote)
 {
  $imFileName="images".chr(47).$theNote."w.png";
  $im=LoadPNG($imFileName);
  imagecopy ( $image, $im, ($noteNum+1)*20, 0, 0, 0, 20, 20);
  //echo "<img height=$imageSize width=$imageSize src=\"images".chr(47).$theNote.".png\">";  
 }

 //echo "<br>";
 $yCounter=0;

 for($currentFret=$startFret;$currentFret<=$endFret;$currentFret++)
 {
  $yCounter++;

  if($thesciPosition==-1) 
   $imFileName="images".chr(47)."xw.png";
  else
   $imFileName="images".chr(47).$currentFret."w.png";

  $im=LoadPNG($imFileName);
  imagecopy ( $image, $im, 0, ($yCounter)*20, 0, 0, 20, 20);

     //echo "<img height=$imageSize width=$imageSize src=\"images".chr(47).$currentFret.".png\">";
   foreach ($tuningArray as $stringNum => $theString)
   {
     if($sciPositionArray[$stringNum]==$currentFret)
     {
      $imFileName="images".chr(47)."filledCirclew.png";
      $im=LoadPNG($imFileName);
      imagecopy ( $image, $im, ($stringNum+1)*20, ($yCounter)*20, 0, 0, 20, 20);
            //echo "<img height=$imageSize width=$imageSize src=\"images".chr(47)."openCircle.png\">";  
     }
     else
     {
      $imFileName="images".chr(47)."spacerw.png";
      $im=LoadPNG($imFileName);
      imagecopy ( $image, $im, ($stringNum+1)*20, ($yCounter)*20, 0, 0, 20, 20);
            //echo "<img height=$imageSize width=$imageSize src=\"images".chr(47)."spacer.png\">";  
     }
   }     
      //echo "<br>";
 }
 $imFileName="images".chr(47)."upperSpacerw.png";
 $im=LoadPNG($imFileName);
 imagecopy ( $image, $im, 0, ($yCounter+1)*20, 0, 0, 20, 20);
  //echo "<img height=$imageSize width=$imageSize src=\"images".chr(47)."upperSpacer.png\">";  

 foreach ($sciPositionArray as $sciPositionNum => $thesciPosition)
 {
  if($thesciPosition==-1) $thesciPosition="x";
  $imFileName="images".chr(47)."u".$thesciPosition."w.png";
  $im=LoadPNG($imFileName);
  imagecopy ( $image, $im, ($sciPositionNum+1)*20, ($yCounter+1)*20, 0, 0, 20, 20);
   //echo "<img height=$imageSize width=$imageSize src=\"$imFileName\">";  
 }
 //echo "<br>";


// Define .PNG image


// Output graph and clear image from memory

imagepng($image);

imagedestroy($image);
?>