<?php
 set_time_limit(20000);
 include_once("config.php");
 include_once("libDatabase.php");
 include_once("libGeneral.php");
 include_once("libGraphics.php");
 include_once("libString.php");
 connect();
 header("Content-type: image/x-png");

 $startNote = $_GET['startNote'];
 $spelling=implode(",", explode("|", "1|".$_GET['spelling']));
 $spellingArray=explode(",", $spelling);
 $tuning=implode(",", explode("|", $_GET['tuning']));
 $stringArray=explode(",", $tuning);

 if(isset($_GET['size']))
  $size=$_GET['size'];
 else	
  $size=10;

 if(isset($_GET['maxFrets']))
  $maxFrets=$_GET['maxFrets'];
 else
  $maxFrets=12;

 if(isset($_GET['show'])) 
 {
  $show=$_GET['show'];
  if($show=="all")
   if($size<22) $size=22;
  else
   if($size<11) $size=11;
  
 }
 else
  $show="";
  
 $imgWidth=$size*(count($stringArray));
 $imgHeight=$size*($maxFrets+1);

 $image=imagecreatetruecolor($imgWidth, $imgHeight);

 $colorWhite=imagecolorallocatealpha($image, 255, 255, 255,0);
 $colorBlack=imagecolorallocatealpha($image, 0, 0, 0,0);
 $colorLightGrey=imagecolorallocatealpha($image, 230, 230, 230,0);

 imagefilledrectangle ($image, 0, 0, $imgWidth, $imgHeight, $colorWhite);
 
 for( $fretNum=0; $fretNum<=$maxFrets; $fretNum++ )
 {
  foreach ($stringArray as $stringNum => $string)
  {
   $currentNum = note2num($string)+$fretNum;
   $currentNote=num2note($currentNum, $startNote);
   $startNoteNum = note2num($startNote);
   $sc = num2sc(($currentNum + 12 - $startNoteNum)%12);
   $matchesSpelling =in_array($sc, $spellingArray); 

   if($matchesSpelling) 
   {
    $activeColor=$colorBlack;
    imagefilledrectangle ($image, $stringNum*$size, $fretNum*$size, $stringNum*$size+($size-1), $fretNum*$size+($size-1), $activeColor);

    if($show=="all")
    {
     if(strlen($sc)>1)
      $scoffset=1;
     else
      $scoffset=3;

     if(strlen($currentNote)>1)
      $cnoffset=1;
     else
      $cnoffset=3;

     imagestring($image, 1, $stringNum*$size+$scoffset, $fretNum*$size+1, $sc, $colorWhite);
     imagestring($image, 1, $stringNum*$size+$cnoffset+($size/2), $fretNum*$size+1, $currentNote, $colorWhite);
    }
    else
    {
     if($show=="note") $showThis=$currentNote;
     if($show=="sc") $showThis=$sc;
        
     if(strlen($showThis)>1)
      $offset=1;
     else
      $offset=3;
     
     imagestring($image, 1, $stringNum*$size+$offset, $fretNum*$size+1, $showThis, $colorWhite);
    }
   }
   else
   {
    if(fretNumIsFretGuide($fretNum))
    {
     $activeColor=$colorLightGrey;
     imagefilledrectangle ($image, $stringNum*$size, $fretNum*$size, $stringNum*$size+($size-1), $fretNum*($size)+($size-1), $activeColor);
    }
    else
    {
     $activeColor=$colorWhite;
     imageline ( $image, $stringNum*$size, $fretNum*$size, $stringNum*$size, $fretNum*$size+($size-1), $colorLightGrey);
     imageline ( $image, $stringNum*$size, $fretNum*$size, $stringNum*$size+($size-1), $fretNum*$size, $colorLightGrey);
     imageline ( $image, $stringNum*$size+($size-1), $fretNum*$size, $stringNum*$size+($size-1), $fretNum*$size+($size-1), $colorLightGrey);
    }
   }
  }
 }
 // Output graph and clear image from memory
 imagepng($image);
 imagedestroy($image);
?>