phpMyChord

Created by Benjamin Kinsey, bk@bksy.com

project home page: https://sourceforge.net/projects/phpmychord/

Installation instructions:
unzip all files into www directory
e.g. C:\wamp\www

Using phpMyAdmin or equivalent, run initializeDatabase.sql