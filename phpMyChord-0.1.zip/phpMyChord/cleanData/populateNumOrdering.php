<?php
 set_time_limit(20000);
 include_once("..\config.php");
 include_once("..\libDatabase.php");
 connect();
 include_once("..\libGeneral.php");
 include_once("..\libGraphics.php");
 include_once("..\libString.php");

 populateNumOrdering(); 
?>