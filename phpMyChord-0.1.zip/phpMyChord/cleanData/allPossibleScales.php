<html>
 <body>
  <table>
  <?php 
 set_time_limit(20000);
 include_once("..\config.php");
 include_once("..\libDatabase.php");
 connect();
 include_once("..\libGeneral.php");
 include_once("..\libGraphics.php");
 include_once("..\libString.php");

  for($i=0;$i<=12;$i++)
  {
   $ct[$i]=0;
  }
   for($i=0;$i<=2047;$i++)
   {
    $spelling=numOrdering2spelling($i);
    $numNotes=count(explode(",", $spelling))+1;
    $symmetricalFormNumber=spelling2numSymForms($spelling);
    $maxInARow=spelling2numHalfStepsInRow($spelling);
    $preferredCode=getPreferredCode($spelling);
   //$sql="UPDATE tblMusScale SET numHalfStepsInRow=$maxInARow WHERE txtSpelling='$spelling'";
   //$result = mysql_query($sql) or die("Invalid query: ".mysql_error()." sql: ".$sql); 
     $numIntervalForm=spelling2numIntervalForm($spelling);
     echo "<tr><td>I$numIntervalForm</td><td>$spelling</td><td>$i</td><td>$numNotes</td><td>$preferredCode</td><td>$maxInARow</td><td>$symmetricalFormNumber</td></tr>";

     $symmetricalFormsByNumNotes[$symmetricalFormNumber][$numNotes]++;
   }
   echo "</table>";

  for($symmetricalFormNumber=0;$symmetricalFormNumber<=5;$symmetricalFormNumber++)
   for($i=1;$i<=12;$i++)
   {
    echo "symmetricalFormsByNumNotes[$symmetricalFormNumber][$i]=".$symmetricalFormsByNumNotes[$symmetricalFormNumber][$i]."<br>";
  }
  
  
  
  
  
  
  
  
  
  ?>

 </body>
</html>
