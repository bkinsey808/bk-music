<?php
 function drawKey($image, $YReference, $theKey, $keyWidth, $bKeyLen, $wKeyLen, $keyboardXOffset, $colorLightGrey, $colorBlack)
 {
  $color=$colorBlack;
  if($theKey=="C" || $theKey=="F" )
  {
   imageline ( $image, $keyboardXOffset,$YReference,$keyboardXOffset+$wKeyLen,$YReference, $color);
   imageline ( $image, $keyboardXOffset,$YReference+($keyWidth*1/4),$keyboardXOffset+$bKeyLen,$YReference+($keyWidth*1/4), $color);
   imageline ( $image, $keyboardXOffset+$bKeyLen,$YReference+($keyWidth),$keyboardXOffset+$wKeyLen,$YReference+($keyWidth), $color);
   imageline ( $image, $keyboardXOffset,$YReference,$keyboardXOffset,$YReference+($keyWidth*1/4), $color);
   imageline ( $image, $keyboardXOffset+$bKeyLen,$YReference+($keyWidth*1/4),$keyboardXOffset+$bKeyLen,$YReference+($keyWidth), $color);
   imageline ( $image, $keyboardXOffset+$wKeyLen-1,$YReference,$keyboardXOffset+$wKeyLen-1,$YReference+($keyWidth), $color);
   $newYReference=$YReference+$keyWidth*1/4;
  }
  else if($theKey=="Db" || $theKey=="Eb" || $theKey=="Gb" || $theKey=="Ab" || $theKey=="Bb")
  {
   imageline ( $image, $keyboardXOffset,$YReference,$keyboardXOffset+$bKeyLen-1,$YReference, $color);
   imageline ( $image, $keyboardXOffset,$YReference+($keyWidth),$keyboardXOffset+$bKeyLen-1,$YReference+($keyWidth), $color);
   imageline ( $image, $keyboardXOffset,$YReference,$keyboardXOffset,$YReference+($keyWidth), $color);
   imageline ( $image, $keyboardXOffset+$bKeyLen-1,$YReference,$keyboardXOffset+$bKeyLen-1,$YReference+($keyWidth), $color);
   $newYReference=$YReference+$keyWidth;
  }
  else 
   $newYReference=$YReference+$keyWidth;
  return $newYReference+1;
 }
  
 include_once("db.php");
 connect();
 include_once("ml1.php");
 include_once("ml2.php");
 include_once("ml3.php");
 set_time_limit(20000);
 header("Content-type: image/x-png");

 $startNote = $_GET['startNote'];
 $spelling=implode(",", explode("|", "1|".$_GET['spelling']));
 $spellingArray=explode(",", $spelling);


 if(isset($_GET['firstKey']))
  $firstKey=$_GET['firstKey'];
 else	
  $firstKey="C";

 if(isset($_GET['numOctaves']))
  $numOctaves=$_GET['numOctaves'];
 else	
  $numOctaves=1;

 if(isset($_GET['lastKey']))
  $lastKey=$_GET['lastKey'];
 else	
  $lastKey="C";

 $numKeys=12*$numOctaves+note2num($lastKey)+1;
 
 if(isset($_GET['wKeyLen']))
  $wKeyLen=$_GET['wKeyLen'];
 else	
  $wKeyLen=40;

 if(isset($_GET['bKeyLen']))
  $bKeyLen=$_GET['bKeyLen'];
 else	
  $bKeyLen=30;

 if(isset($_GET['keyWidth']))
  $keyWidth=$_GET['keyWidth'];
 else	
  $keyWidth=10;

 if(isset($_GET['buttonDist']))
  $buttonDist=$_GET['buttonDist'];
 else	
  $buttonDist=10;

 if(isset($_GET['buttonDia']))
  $buttonDia=$_GET['buttonDia'];
 else	
  $buttonDia=8;

 if(isset($_GET['keyboardXOffset']))
  $buttonDia=$_GET['keyboardXOffset'];
 else	
  $keyboardXOffset=30;
  
 $imgWidth=($keyboardXOffset+$wKeyLen);
 $imgHeight=($numKeys*7/12)*$keyWidth;


 $image=imagecreatetruecolor($imgWidth, $imgHeight);

 $colorWhite=imagecolorallocatealpha($image, 255, 255, 255,0);
 $colorBlack=imagecolorallocatealpha($image, 0, 0, 0,0);
 $colorLightGrey=imagecolorallocatealpha($image, 230, 230, 230,0);

 imagefilledrectangle ($image, 0, 0, $imgWidth, $imgHeight, $colorWhite);

 $YReference=0;
 for($keyNum=0;$keyNum<$numKeys;$keyNum++ )
 {
  $YReference=drawKey($image, $YReference, num2note($keyNum,"C"), $keyWidth, $bKeyLen, $wKeyLen, $keyboardXOffset, $colorLightGrey, $colorBlack);
 }

 
 // Output graph and clear image from memory

 imagepng($image);
 imagedestroy($image);
?>