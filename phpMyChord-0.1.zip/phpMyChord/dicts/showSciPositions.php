<?php 
 set_time_limit(20000);
 include_once("..\config.php");
 include_once("..\libDatabase.php");
 include_once("..\libGeneral.php");
 include_once("..\libGraphics.php");
 include_once("..\libString.php");
 connect();

 $instruments[1]['tuning']="G,C,E,A";
 $instruments[1]['name']="Ukulele";
 $instruments[1]['maxMutedStringsOfChord']=0;
 $instruments[1]['maxFretSpanOfChord']=0;

 $instruments[2]['tuning']="E,A,D,G";
 $instruments[2]['maxMutedStringsOfChord']=0;
 $instruments[2]['maxFretSpanOfChord']=0;

 $instruments[3]['tuning']="E,A,D,G,B,E";
 $instruments[3]['maxMutedStringsOfChord']=1;
 $instruments[3]['maxFretSpanOfChord']=0;

 $songs[1]['name']="1. Example Song Title";
 $songs[1]['sciSequence']="A M;C M";
 $songs[2]['name']="14. Another Example Song Title";
 $songs[2]['sciSequence']="G -;D 7;C -";
  
 
 foreach($instruments as $instrument)
 {
  $barTuning=implode("|", explode(",",$instrument['tuning']));
  $tuning=$instrument['tuning'];
  $instrumentName=$instrument['name'];
  $tuningArray=explode(",",$tuning);
  $fretboardSize=12;
  $maxMutedStringsOfChord=$instrument['maxMutedStringsOfChord'];
  $maxFretSpanOfChord=4;
 
  foreach($songs as $sn => $song)
  {
   $sciSequence=$song['sciSequence'];
   $sciSequenceArray=explode(";",$sciSequence);
   $songName=$song['name'];
   if($sn>0) echo "<span STYLE=\"page-break-before: always\">";
   echo "<font size=6><u>$songName</u> <strong>$sciSequence</strong></font> <font size=4>($tuning $instrumentName)</font></h1>";
   $expandedSciSequence=expandSciSequence($sciSequence);
   $expandedSciSequenceArray=explode(";",$expandedSciSequence);
   //echo "Chords: $sciSequence&nbsp;&nbsp;&nbsp;Keys: $expandedSciSequence<br>";
   
   
   
   foreach($sciSequenceArray as $sci)
   {
    $sciPositionArray=getSciPositionArray
    ( 
     $sci,
     $tuning,
     $fretboardSize,
     $maxMutedStringsOfChord,
     $maxFretSpanOfChord,
     13
    ); 

    $spelling=sci2spelling($sci);
    $startNote=sci2startNote($sci);
    
    $barSpelling=implode("|", explode(",",$spelling));
    echo "<h3>$sci for $tuning</h3>";
    echo "<img src=\"..".chr(47)."imgFretboard.php?startNote=$startNote&spelling=$barSpelling&tuning=$barTuning\">&nbsp;"; 

    if(is_array($sciPositionArray))
    {
     foreach($sciPositionArray as $sciPosition)
     {
      $notes=sciPosition2notes($sciPosition,"C",$tuning);
      $barSciPosition=implode("|", explode(",",$sciPosition));
      echo "<img src=\"..".chr(47)."imgSciPosition.php?sciPosition=$barSciPosition&tuning=$barTuning\">&nbsp;";
     }
    }
   }
   $thisSci=$expandedSciSequenceArray[0];
   $subSciArray=getSubSciArray($thisSci,count($tuningArray));
   $subSciSequence=implode(";",$subSciArray);
   echo "<br>Experimental Chords for $tuning:<br>";
   foreach($subSciArray as $subSci)
   {
    $sciPositionArray=getSciPositionArray
    ( 
     $subSci,
     $tuning,
     $fretboardSize,
     $maxMutedStringsOfChord,
     $maxFretSpanOfChord,
     13
    );
    $firstSciPosition=negativeOne2x($sciPositionArray[1]);
    $inSeq=sciInSciSequence($subSci, $sciSequence);
    if($firstSciPosition<>"" && !$inSeq)
     echo "$subSci ($firstSciPosition); ";
   }
   echo "<br><br>Circle of Fifths for $tuning:<br>";
   echo "<table border=1>";
   for($i=0;$i<=11;$i++)
   {
   	$numOfInterval=((($i+7)*7)%12);
    $transposedSciSequence=transposeSciSequence($sciSequence, $numOfInterval);
    $transposedExpandedSciSequence=transposeSciSequence($expandedSciSequence, $numOfInterval);
    $transposedSciSequenceArray=explode(";",$transposedSciSequence);

   	echo "<tr>";
    echo "<td>";
    if($numOfInterval==0) echo "<b>";
   	echo num2sc($numOfInterval);
    echo "</td>";
    echo "<td>";
    if($numOfInterval==0) echo "<b>";
    echo "$transposedExpandedSciSequence";
    echo "</td>";
    echo "<td>";
    if($numOfInterval==0) echo "<b>";
    foreach($transposedSciSequenceArray as $n => $transposedSci)
    {
     $sciPositionArray=getSciPositionArray
     ( 
      $transposedSci,
      $tuning,
      $fretboardSize,
      $maxMutedStringsOfChord,
      $maxFretSpanOfChord,
      13
     );
     $firstSciPosition=negativeOne2x($sciPositionArray[1]);
     if($n>0) echo ";";
     echo "$transposedSci ($firstSciPosition)";     
    }
    echo "</td>";
   	echo "</tr>";
   }
   echo "</table>";
  }
 }
?>