<?php
 function dbExecute($sql)
 {
  $result = mysql_query($sql) or die("Invalid query: ".mysql_error()." sql: ".$sql);
 }
 function dbSelect($sql)
 {
  $result = mysql_query($sql) or die("Invalid query: ".mysql_error()." sql: ".$sql);
  $num_rows = mysql_num_rows($result);
  if( $num_rows > 0 ) 
  {
   $fields = mysql_num_fields($result);
   for( $j=1; $row=mysql_fetch_array($result); $j++) 
   {
    for( $i=0; $i<$fields; $i++)  
    {
     $name=mysql_field_name($result, $i);
     $resultArray[$j][$name] = $row[$name];
    } //end for
   } //end while
  }
  return $resultArray;
 }
 function dbString( $str ) 
 {
  return "\"".mysql_escape_string($str)."\"";
 }
 function dbPassword( $str ) 
 {
  return "password(\"".mysql_escape_string($str)."\")";
 }

 function dbSafe( $key, $val ) 
 {
  if($key == "txtPassword")
    return "password(\"".mysql_escape_string($val)."\")";
  else if( substr($key, 0, 3) == "txt" )
    return "\"".$val."\"";
  else if (substr($key, 0, 3) == "boo" && $val == "false")
    return "0";
  else if (substr($key, 0, 3) == "boo" && $val == "true")
    return "1";
  else
    return $val;
 }

 function formatWithKey($a, $key) 
 {
  if (substr($key, 0, 3) == "txt")
   return "\"".$a[$key]."\"";
  else
   if (substr($key, 0, 3) == "boo" && $a[$key] == "false")
    return "0";
   else
    if (substr($key, 0, 3) == "boo" && $a[$key] == "true")
     return "1";
    else
   return $a[$key];
 }
?>