<?php
function drawChordPosition($chordPosition,$strings)
{
 $lowestFret=getLowestFret($chordPosition);
 $highestFret=getHighestFret($chordPosition);
 $stringArray=explode(",", $strings);
 $chordPositionArray=explode(",", $chordPosition);
  
 $notes=chordPo2Notes($chordPosition, "C", $strings);
 echo "<img src=\"images".chr(47)."lowerLine.png\">";  
 foreach (explode(",",$notes) as $noteNum => $theNote)
 {
   echo "<img src=\"images".chr(47).$theNote.".png\">";  
 }
 echo "<br>";
 for($currentFret=$lowestFret;$currentFret<=$highestFret;$currentFret++)
 {
   echo "<img src=\"images".chr(47).$currentFret.".png\">";
   foreach ($stringArray as $stringNum => $theString)
   {
     if($chordPositionArray[$stringNum]==$currentFret)
     {
      echo "<img src=\"images".chr(47)."openCircle.png\">";  
     }
     else
     {
      echo "<img src=\"images".chr(47)."spacer.png\">";  
     }
   }     
   echo "<br>";
 }
}

function showChordList($chordArray)
{
 $noteAndChordArray="";
 $noteAndChordNum=0;
 
 if(is_array($chordArray))
 foreach ($chordArray as $chordNum => $chord)
 {
  if($chord['booPrefer']==1||1==1)
  {
   $names = "";
   if($chord['txtName'] <> $chord['txtCode'])
   {
    $names=$chord['txtName'];
    if($chord['txtAltNames'] <> "")
     $names.=", ";
   }
   $names.=$chord['txtAltNames']; 

   $modeArray=getModeArray($chord['txtSpelling']);

   $found = false;
   $noteAndChordCode=$chord['startNote']." ".$chord['txtCode'];
   if(is_array($noteAndChordArray))
   {
    foreach($noteAndChordArray as $noteAndChordToCheckNum => $noteAndChordToCheck)
    {
     if($noteAndChordToCheck==$noteAndChordCode)
      $found=true;
    }
   }
  
   if(!$found) 
   {
    $noteAndChordArray[$noteAndChordNum++]=$noteAndChordCode;
    $completeChordName = $noteAndChordCode." ";

    foreach ($modeArray as $modeNum => $thisMode) 
    {
     $modeNote=num2note(note2num($startNote)+sc2num($thisMode[0]),$referenceNote);
     $outMSc = $thisMode[1];
     $inversionChordArray=getScaleArrayFromSpelling($outMSc);
     if(is_array($inversionChordArray))
     {
      foreach ($inversionChordArray as $inversionChordNum => $inversionChord) 
      {
       $modeNoteAndChord=$modeNote." ".$inversionChord['txtCode'];
       $found=false;
       foreach($noteAndChordArray as $noteAndChordToCheckNum => $noteAndChordToCheck)
       {
        if($noteAndChordToCheck==$modeNoteAndChord)
         $found=true;
       }
       if(!$found)
       {
        $noteAndChordArray[$noteAndChordNum++]=$modeNoteAndChord;
        $completeChordName .= " / $modeNoteAndChord";
        echo "note: ".$chord['startNote']."<br>";
        echo "spelling: ".$chord['txtSpelling']."<br>";
        echo "names: $names<br>";
        echo "completeChordName: $completeChordName<br>";   
       }                   	
      }
     }
    }
   }
  }
 }
}

//------------------------------------------------getScaleArrayFromSpelling
function getScaleArrayFromSpelling($txtSpelling)
{
  $sql ="SELECT * FROM tblMusScale where txtSpelling='$txtSpelling' ORDER BY numNote"; 

  //echo $sql;
  $result = mysql_query($sql) or die("Invalid query: ".mysql_error()." sql: ".$sql);
  $num_rows = mysql_num_rows($result);
  if( $num_rows > 0 ) 
  {
    $fields = mysql_num_fields($result);
    for( $j=1; $row=mysql_fetch_array($result); $j++) {
      for( $i=0; $i<$fields; $i++)  {
        $name=mysql_field_name($result, $i);
        $scaleArray[$j][$name] = $row[$name];
      } //end for
    } //end while
   }
return $scaleArray;
}
function displayModeArray($modeArray,$spelling,$code,$referenceNote,$strings,$totalFrets,$nutPos,$fretSpan,$chordNumber)
{
  if(is_array($modeArray))
  {
    echo "<ul>";
    foreach ($modeArray as $modeNum => $thisMode )
    {
      echo "<li>";
      if($referenceNote!="")
        echo $referenceNote." ";
      echo "$code Mode ".$thisMode[0].": ";

      if($referenceNote!="")
        $modeNote=num2note(note2num($referenceNote)+sc2num($thisMode[0]),$referenceNote);
      
      $outMSc = $thisMode[1];
      $scaleArray=getScaleArrayFromSpelling($outMSc);
      if(is_array($scaleArray))
        foreach ($scaleArray as $scaleNum => $scale) 
        {
          echo "<a href=\"test.php?sourceType=spelling&note=$modeNote&source=$thisMode[1]&nutPos=$nutPos&strings=$strings&frets=$totalFrets&fretSpan=$fretSpan&chordNumber=$chordNumber\">$modeNote ";
          echo $scale['txtCode']."</a>, </b>";
        }

      if($referenceNote!="")
        echo "notes: ".spelling2notes($outMSc,$modeNote);
      echo " spelling:".$outMSc;
      echo " relativeSpelling: ".getRelativeSpelling($outMSc,$thisMode[0]);
      if(is_array($scaleArray))
        foreach ($scaleArray as $scaleNum => $scale) 
        {
          echo " (";
          if($scale['txtName'] <> $scale['txtCode'])
          {
            echo $scale['txtName'];
            if($scale['txtAltNames'] <> "")
              echo ", ";
          }
          echo $scale['txtAltNames'].") ";
        }
//        getSubScaleArray($outMSc, $thisMode[0], $modeNote,$strings,$totalFrets,$nutPos,$fretSpan);
      echo "</li>";
    } //close foreach loop
    echo "</ul>";
  }
}

//--------------------------------------------------------getModeArray
function getModeArray($spelling)
{
  $spellingWithOne = "1,".$spelling;
  $numNotes=substr_count($spellingWithOne, ",")+1;
  $realModeNum=0;
  for( $thisMode=1; $thisMode<$numNotes; $thisMode++)
  {
   foreach (explode(",", $spellingWithOne) as $key => $value) 
   {
    if($key==0) $thisModeStartNum = sc2num($value);
    $modeArray[$thisMode][($thisMode+$key)%$numNotes]=$value;
   }
  }

  $outMSc = "";
  for( $thisMode=$numNotes-1; $thisMode>0; $thisMode--)
  {
   $outMSc = "";
   $startNum = sc2num($modeArray[$thisMode][0]);
   for( $thisSc=0; $thisSc < $numNotes; $thisSc++ )
   {
    if( $thisSc >= 2 ) 
      $outMSc.=",";
           
    if( $thisSc >= 1 ) 
    {
      $outMSc .= num2sc
      (
        (
          sc2num($modeArray[$thisMode][$thisSc]) + 12 - $startNum
        )%12
      );
   }
  }
  $realModeArray[$realModeNum][0]=$modeArray[$thisMode][0];
  $realModeArray[$realModeNum][1]=$outMSc;
  $realModeNum++;
  
 }
 return $realModeArray;
}
//-------------------------------------------------------------intervals2scs
function intervals2scs($inString)
{
  $outString="";
  $runningTotal=0;
  foreach (explode(" ", $inString) as $key => $value) 
  {
    $runningTotal+=$value;
    if($outString=="") $outString=num2sc($runningTotal);
    else $outString.=",".num2sc($runningTotal);
  }
  return $outString;
}
//--------------------------------------------------displayFretBoard
function displayFretBoard($strings,$totalFrets,$nutPos,$spelling, $startNote, $showSc, $chordPo, $fretSpan)
{
$colors[1]="Black";
$colors[2]="Blue";
$colors[3]="BlueViolet";
$colors[4]="Brown";
$colors[5]="BurlyWood";
$colors[6]="CadetBlue";
$colors[7]="Chartreuse";
$colors[8]="Chocolate";
$colors[9]="Coral";
$colors[10]="CornflowerBlue";
$colors[11]="Crimson";
$colors[12]="Cyan";
$colors[13]="DarkBlue";
$colors[14]="DarkCyan";
$colors[15]="DarkGoldenRod";
$colors[16]="DarkGray";
$colors[17]="DarkGreen";
$colors[18]="DarkKhaki";
$colors[19]="DarkMagenta";
$colors[20]="DarkOliveGreen";
$colors[21]="Darkorange";
$colors[22]="DarkOrchid";
$colors[23]="DarkRed";
$colors[24]="DarkSalmon";
$colors[25]="DarkSeaGreen";
$colors[26]="DarkSlateBlue";
$colors[27]="DarkSlateGray";
$colors[28]="DarkTurquoise";
$colors[29]="DarkViolet";
$colors[30]="DeepPink";
$colors[31]="DeepSkyBlue";
$colors[32]="DimGray";
$colors[33]="DodgerBlue";
$colors[34]="Feldspar";
$colors[35]="FireBrick";
$colors[36]="ForestGreen";
$colors[37]="Fuchsia";
$colors[38]="Gainsboro";
$colors[39]="Gold";
$colors[40]="GoldenRod";
$colors[41]="Gray";
$colors[42]="Green";
$colors[43]="GreenYellow";
$colors[44]="HotPink";
$colors[45]="IndianRed";
/*
"Indigo",
"Ivory",
"Khaki",
"Lavender",
"LavenderBlush",
"LawnGreen",
"LemonChiffon",
"LightBlue",
"LightCoral",
"LightCyan",
"LightGoldenRodYellow",
"LightGrey",
"LightGreen",
"LightPink",
"LightSalmon",�
"LightSeaGreen",�
"LightSkyBlue",
"LightSlateBlue",�
"LightSlateGray",
"LightSteelBlue",
"LightYellow",
"Lime",
"LimeGreen",
"Linen",
"Magenta",�
"Maroon",
"MediumAquaMarine",
"MediumBlue",
"MediumOrchid",�
"MediumPurple",
"MediumSeaGreen",�
"MediumSlateBlue",
"MediumSpringGreen",�
"MediumTurquoise",
"MediumVioletRed",
"MidnightBlue",
"MintCream",
"MistyRose",
"Moccasin",
"NavajoWhite",
"Navy",
"OldLace",
"Olive",
"OliveDrab",
"Orange",
"OrangeRed",
"Orchid",
"PaleGoldenRod",
"PaleGreen",
"PaleTurquoise",
"PaleVioletRed",
"PapayaWhip",
"PeachPuff",
"Peru",
"Pink",
"Plum",
"PowderBlue",
"Purple",
"Red",
"RosyBrown",
"RoyalBlue",
"SaddleBrown",�
"Salmon",
"SandyBrown",
"SeaGreen",
"SeaShell",
"Sienna",
"Silver",
"SkyBlue",
"SlateBlue",�
"SlateGray",
"Snow",�
"SpringGreen",
"SteelBlue",
"Tan",
"Teal",
"Thistle",
"Tomato",
"Turquoise",
"Violet",
"VioletRed",
"Wheat",
"WhiteSmoke",
"Yellow",
"YellowGreen");
*/
 
 $spellingArray=explode(",", "1,".$spelling);
 $startNum = note2num($startNote);
 $stringArray=explode(",", $strings);
 $chordPoArray=explode(",", $chordPo);

 $numNotes = count($spellingArray);
 $numStrings = count($stringArray);

 if($numNotes<=$numStrings)
  $cps = discoverChordPos($strings,$totalFrets, $fretSpan, $nutPos, $spelling,$startNote);
 else
  $cps="";
  
 echo "<table border=1>";

  for( $fretNum=0; $fretNum<=$totalFrets; $fretNum++ )
  {
   echo "<tr>";
   foreach ($stringArray as $stringNum => $string)
   {
    if($fretNum%12==5  || $fretNum%12 ==7 
             || $fretNum%12 ==10 || $fretNum%12 ==0)
     $bgcolor="lightgrey";
          else
     $bgcolor="white";

    echo "<td bgcolor=\"$bgcolor\">";
    $currentNum = note2num($string)+$fretNum;
    $currentNote=num2note($currentNum, $startNote);
    $startNoteNum = note2num($startNote);
    $sc = num2sc(($currentNum + 12 - $startNoteNum)%12);

    $matchesSpelling =in_array($sc, $spellingArray); 

/*
<script type="javascript">
 <!--
 function checkBoxes()
 {
  a=1;
 }
 //-->
</script>
*/
?>
<?php
    if($matchesSpelling) 
    {
     echo "<input name=\"cb$stringNum.$fretNum\" type=\"checkbox\" checked>";
     echo "$currentNote - $sc";
     if(is_array($cps))
     {
      $outs="";
      foreach ($cps as $cpNum => $cp)
      {
       $cpArray = explode(",", $cp);
       if($fretNum==$cpArray[$stringNum])
       { 
       	if($outs=="") $outs .= " {";
       	 $outs .= " <span><font color=" . $colors[$cpNum].">$cpNum</font></span>";
       }
      }
      if($outs!="") $outs .= "}";
      echo "<font size=\"-2\"><b>$outs</b></font>";
     }
    }
    else
     echo "<input name=\"cb$stringNum.$fretNum\" type=\"checkbox\">";    
     
    echo "</td>";
   }
   echo "</tr>";
  }

/*
 if($chordPo != "") 
 {
//  echo "here<br>";
  foreach (explode(",", $strings) as $stringNum => $string) 
  {
   for($fretNum=($nutOnLeft?0:$totalFrets);
    $nutOnLeft?$fretNum<=$totalFrets:$fretNum>=0; 
    $nutOnLeft?$fretNum++:$fretNum--)
   {
    if($fretNum%12==5  || $fretNum%12 ==7 
             || $fretNum%12 ==10 || $fretNum%12 ==0)
     $img="lightgray";
          else
     $img="white";
    $currentNum = note2num($string)+$fretNum;
    if($fretNum==$chordPoArray[$stringNum])
     $img="black";

//    echo "$totalFrets / $fretNum / $img <br>";
    echo "<img src=\"$img.GIF\" width=\"4\" height=\"4\" border=\"0\">";
    if(($nutOnLeft && $fretNum==$totalFrets) || (!$nutOnLeft && $fretNum==0))
     echo "<br>";
   }
  }
 }
*/
}

?>