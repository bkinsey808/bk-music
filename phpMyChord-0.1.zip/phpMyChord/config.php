<?php  
function connect() {
	
 $dbURL="localhost";
 $dbUsername="";
 $dbPassword="";
 $dbName="music";

 $db = mysql_connect($dbURL, $dbUsername, $dbPassword) or die('I cannot connect to the database because: '.mysql_error());
 mysql_select_db("$dbName") or die(mysql_error());
}
?>