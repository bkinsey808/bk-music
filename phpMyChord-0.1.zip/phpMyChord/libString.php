<?php 
 function fretNumIsFretGuide($fretNum)
 {
  return 
  (
      $fretNum%12 == 5 
   || $fretNum%12 == 7 
   || $fretNum%12 == 10 
   || $fretNum%12 == 0
  );
 } 

function sciPosition2Notes($sciPosition, $referenceNote, $tuning)
{
 $sciPositionArray=explode(",", $sciPosition);
 $tuningArray=explode(",", $tuning);

 $n=0;
 foreach ($sciPositionArray as $numSciPositionElement => $sciPositionElement)
 {
  if($cp <> "x" && $cp <> "-1") 
  {
   $note[$n]=num2note((note2num($tuningArray[$numSciPositionElement])+$sciPositionElement)%12,$referenceNote);
   //echo "chordPo:$chordPo note:".$note[$n]."<br>";
  }
  else
  {
   $note[$n]="x";
  }
  $n++;
 }
 if($n>0)
  $notes = implode(",", $note);
 else $notes="";
 return $notes;
}

 function chordInScale($cp, $note, $spelling, $strings)
 {
  $notes=spelling2notes($spelling,$note);
  $noteArray=explode(",", $notes);
  $chordNotes=chordPo2notes($cp, "C", $strings);
  $chordNoteArray=explode(",", $chordNotes);
  $allChordNotesFound=true;
  foreach ($chordNoteArray as $thisChordNoteNum => $thisChordNote)  
  {
   if($thisChordNote != "x" && $thisChordNote != "-1")
   {
    $thisChordNoteFound=false;
    foreach ($noteArray as $thisNoteNum => $thisNote)  
     if($thisChordNote==$thisNote)
      $thisChordNoteFound=true;
    if($thisChordNoteFound==false)
     $allChordNotesFound=false;
   }
  }
  return $allChordNotesFound;
 }
 
 function getNumFrets($chordPo)
 {
  $numFrets=0;
  foreach (explode(",",$chordPo) as $cpNum => $cp)
  {
   if($cp<>"0" && $cp<>"x")
    $numFrets++;
  }
  return $numFrets;
 }

function getFretWidth($chordPo)
{
  return getHighestFret($chordPo)-getLowestFret($chordPo);
}
function getFretAverage($chordPo)
{
 $chordPoArray = explode(",", $chordPo);
 $numNonZero = 0;
 $sumNonZero = 0;
 foreach ($chordPoArray as $cpNum => $cp)
 {
  if($cp<>"0" && $cp<>"x")
  {
   $numNonZero++;
   $sumNonZero+=intval($cp);
  }
 }
 if($numNonZero != 0) return $sumNonZero/$numNonZero;
 else return 0;
}
function getTotalFrets($chordPo)
{
 $chordPoArray = explode(",", $chordPo);
 $numNonZero = 0;
 $sumNonZero = 0;
 foreach ($chordPoArray as $cpNum => $cp)
 {
  if($cp<>"0" && $cp<>"x")
  {
   $numNonZero++;
   $sumNonZero+=intval($cp);
  }
 }
 return $sumNonZero;
}

 //Fix this!!!!
 function getChordNumbers($source, $sourceType, $fretSpan)
 {
  return 4;
 }

function chordPo2spellingAndNoteArray($chordPo,$strings)
{
 //echo "chordPo:$chordPo, strings:$strings<br>";
 $allScs="b2,2,b3,3,4,b5,5,b6,6,b7,7";
 $allScsArray=explode(",", $allScs);
 $stringArray=explode(",", $strings);
 $chordPoArray=explode(",", $chordPo);

 foreach ($chordPoArray as $cpNum => $cp)
 {
  if($cp<>"x" && $cp<>"-1")
  {
   $outSpelling="";
   $cpVal = (intval($cp)+note2num($stringArray[$cpNum]))%12;
   $cpNote=num2note($cpVal,$stringArray[$cpNum]);
   //echo "note:$cpNote $cpNum $cpVal cp:$cp<br>";

   foreach ($allScsArray as $scNum => $sc)
   {
    $scVal=(sc2num($sc)+$cpVal)%12;

    foreach ($stringArray as $stringNum => $string)
    {
     $stringVal=intval(note2num($string));

     //cpVal is the value of the note that is the first scale degree
     //for a particular string, what is the chordPo?
     $chordPoAtString=$chordPoArray[$stringNum];
     
     if($chordPoAtString!="x" && $chordPoAtString != "-1")
     {
      $frettedStringVal=(intVal($chordPoAtString)+$stringVal)%12;

      if($scVal==$frettedStringVal)
      {
       $outSpellingArray=explode(",", $outSpelling);
       if(!in_array($sc, $outSpellingArray))
       {
        if($outSpelling!="") $outSpelling.=",";
        $outSpelling.=$sc;
       }
      }
     }
    }
   }
   $found=false;
   if(is_array($spellingAndNoteArray))
    foreach($spellingAndNoteArray as $sanaNum => $sana)
     if($sana[0]==$outSpelling && $sana[1]==$cpNote)
   	  $found=true;
   if(!$found)
   {
    $spellingAndNoteArray[$cpNum][0]=$outSpelling; 
    $spellingAndNoteArray[$cpNum][1]=$cpNote;
   } 
  }
 }
 
 return $spellingAndNoteArray;
} 


function negativeOne2x($chordPo)
{
 return str_replace("-1","x",$chordPo);
}
//----------------------------------------------------drawClickable fretBoard
function drawClickableFretBoard($strings,$totalFrets,$nutPos,$spelling, $startNote, $showSc, $chordPo, $chordNumber)
{
 $spellingArray=explode(",", "1,".$spelling);
 $startNum = note2num($startNote);
 $stringArray=explode(",", $strings);
 $chordPoArray=explode(",", $chordPo);
 $nutOnLeft=$nutPos=="left";
  echo "<table>";
  foreach (explode(",", $strings) as $stringNum => $string) 
  {
   echo "<tr>";
   for($fretNum=($nutOnLeft?0:$totalFrets);
    $nutOnLeft?$fretNum<=$totalFrets:$fretNum>=0; 
    $nutOnLeft?$fretNum++:$fretNum--)
   {
    if($fretNum%12==5  || $fretNum%12 ==7 
             || $fretNum%12 ==10 || $fretNum%12 ==0)
     $bgcolor="#f0f0f0";
          else
     $bgcolor="white";
    echo "<td bgcolor=\"$bgcolor\">";
    $currentNum = note2num($string)+$fretNum;
    $chk=($fretNum==$chordPoArray[$stringNum]);

    echo "<input type=\"checkBox\" selected=\"$chk\">";
    if(($nutOnLeft && $fretNum==$totalFrets) || (!$nutOnLeft && $fretNum==0))
     echo "<br>";
    echo "</td>";

   }
   echo "</tr>";
  }
 echo "</table>";
}
//----------------------------------------------------getLowestFret
function getLowestFret($chordPos)
{
 $lowest=1000;
 foreach (explode(",", $chordPos) as $chordPoNum => $chordPo) 
 {
  if($chordPo<>"x"&&$chordPo<>"-1")
  {
   $chordPo=intval($chordPo);
   if($chordPo != 0 && $chordPo < $lowest) 
    $lowest=$chordPo;
  }
 }
 if($lowest==1000) $lowest=0;
 return $lowest;
}
function getHighestFret($chordPos)
{
 $highest=0;
 foreach (explode(",", $chordPos) as $chordPoNum => $chordPo) 
 {
  if($chordPo<>"x")
  {
   $chordPo=intval($chordPo);
   if($chordPo != 0 && $chordPo > $highest) 
    $highest=$chordPo;
  }
 }
 return $highest;
}
//----------------------------------------------------includesEveryNote
function includesEveryNote($chordPos,$strings,$spelling,$startNote)
{
// echo "spelling: $spelling chordPos:$chordPos<br>";
 $found=true;
 $stringArray = explode(",",$strings);
 foreach (explode(",", $spelling) as $scNum => $sc) 
 {
  $noteNum = sc2num($sc) + note2num($startNote);
  $foundInString=false;
  foreach (explode(",", $chordPos) as $chordPoNum => $chordPo) 
  {
   //echo "chordpo: $chordPo<br>";
   if($chordPo!="-1")
   {
    $stringNum=note2num($stringArray[$chordPoNum])+$chordPo;
    if($stringNum %12 == $noteNum % 12) 
    {
     //echo "found for scNum:$scNum ($sc)<br>";
     $foundInString=true;
    }
   }
  }
  if(!$foundInString) {
   //echo "not found for scNum:$scNum ($sc)<br>";
   $found =false;
  }
 }
 return $found;
}
//----------------------------------------------------checkFretSpan
function checkFretSpan($chordPos,$fretSpan)
{
  $maxSoFar =0;
  $minSoFar =1000;
  $fretAverage = getFretAverage($chordPos);
  foreach (explode(",", $chordPos) as $chordPoNum => $chordPo) 
  {
   if($chordPo<>"x"&&$chordPo<>"-1")
   {
    $chordPo=intval($chordPo);
    if($chordPo > 0)
    {
     if($chordPo > $maxSoFar) $maxSoFar = $chordPo;
     if($chordPo < $minSoFar) 
     {
      $minSoFar = $chordPo;
     }
    }
   }
  }
  $diff = $maxSoFar - $minSoFar;
  return ($maxSoFar == 0 || $minSoFar == 1000 || 
   ($diff < $fretSpan)||($fretAverage>12 && $diff <= $fretSpan));
  }

//----------------------------------------------------checkFretSpan
function getFretSpan($chordPos)
{
  $maxSoFar =0;
  $minSoFar =1000;
  foreach (explode(",", $chordPos) as $chordPoNum => $chordPo) 
  {
   if($chordPo<>"x"&&$chordPo<>"-1")
   {
    $chordPo=intval($chordPo);
    if($chordPo != 0)
    {
     if($chordPo > $maxSoFar) $maxSoFar = $chordPo;
     if($chordPo < $minSoFar) 
     {
      $minSoFar = $chordPo;
     }
    }
   }
  }
  $diff = $maxSoFar - $minSoFar;
  return $diff;
  }



//----------------------------------------------------discoverChordPos
function getSciPositionArray
 ( 
  $sci,
  $tuning,
  $fretboardSize,
  $maxMutedStringsOfChord,
  $maxFretSpanOfChord,
  $maxPositions
 )
{
 $spelling=sci2spelling($sci);
 $startNote=sci2startNote($sci);

 //echo "tuning:$tuning fbs:$fretboardSize mfsoc:$maxFretSpanOfChord mmsoc:$maxMutedStringsOfChord sci:$sci spelling: $spelling note:$startNote<br>";	
 //echo "discoverChordPos(strings:$strings,$totalFrets, $fretSpan, $nutPos, $spelling,$startNote,$maxMuted)<br>";
 $chordPosArray = discoverChordPosRecursive($tuning, $fretboardSize, $maxFretSpanOfChord, "1,".$spelling, $startNote, 0, "",$maxMutedStringsOfChord);

 $cnt=count($chordPosArray);
 if($cnt>0)
 {
  $num=1;
  $maxFB=9;
  //  echo "<table>";
  for($fretNum =-1; $fretNum <= $fretboardSize; $fretNum++)
  {
   foreach ($chordPosArray as $chordPoNum => $chordPo) 
   {
       	//echo "checking: $chordPo";
    if(getLowestFret($chordPo) == $fretNum)
    {
     //if(($num-1) % $maxFB ==0)
     //  echo "<tr>";
     //  echo "<td>";
     //     echo round(getFretAverage($chordPo),2)."|".getFretWidth($chordPo)."|".chordPo2Notes($chordPo,$startNote)."|$num |$chordPo|$startNote|$spelling<br>";
     if($num<=$maxPositions)
     {
      $cps[$num]=$chordPo;
      $num++;
     }
    }
   }
  }
  //  echo "</table>";
 }
 return $cps;
}
//----------------------------------------------------discoverChordPosRecursive
function discoverChordPosRecursive($strings, $totalFrets, $fretSpan, $spelling, $startNote, $stringNum, $fretNumsSoFar,$maxMuted)
{
 //echo "strings:$strings<br>";
 //echo "totalFrets:$totalFrets<br>";
 //echo "fretSpan:$fretSpan<br>";
 //echo "spelling:$spelling<br>";
 //echo "startNote:$startNote<br>";
 //echo "stringNum:$stringNum<br>";
 //echo "fretNumsSoFar:$fretNumsSoFar<br><br>";
 $spellingArray =explode(",", $spelling);
 $totalStrings = substr_count($strings, ",")+1;
 if($stringNum<$totalStrings)
 $stringArray=explode(",", $strings);
 $string=$stringArray[$stringNum];
 {
  for($fretNum=-1;$fretNum<=$totalFrets;$fretNum++)
  {
   if($maxMuted>0 && substr_count($fretNumsSoFar,"-1")>=$maxMuted) $fretNum++;
   if($fretNum<=$totalFrets)
   {      
   if($fretNum!=-1)
    $currentNum = note2num($string)+$fretNum;
   
   //echo "fretnum: $fretNum currentNum:$currentNum string:$string<br>";

   $newFretNumsSoFar=$fretNumsSoFar;
   if($newFretNumsSoFar != "") $newFretNumsSoFar.=",";
    $newFretNumsSoFar.=$fretNum;

   $orig=true;
   foreach ($spellingArray as $spellingNum => $sc) 
   {
    $scNum = sc2num($sc);
    $noteNum = $scNum + note2num($startNote);

    if($fretNum==-1||($noteNum % 12 == $currentNum % 12)) 
    {
     //for($i=0;$i<$stringNum;$i++) echo "&nbsp;";
     //echo "matched $stringNum currentNote: ".num2note($noteNum,$startNote)." fretNum:$fretNum $string:<br>";

     $cnt=count($chordPosArray);
     if($stringNum<($totalStrings)-1&&($fretNum!=-1||($fretNum==-1&&$orig)))
     {
      //echo "orig:$orig fretNum: $fretNum<br>";
      $discoveredChordPosArray = discoverChordPosRecursive($strings, $totalFrets, $fretSpan, $spelling, $startNote, $stringNum+1, $newFretNumsSoFar,$maxMuted);
      if(count($discoveredChordPosArray)>0)
      {
       foreach ($discoveredChordPosArray as $discoveredChordPosNum => $chordPos) 
       {
        $chordPosArray[$cnt]=$chordPos;
        //echo "got: $chordPos<br>";
        $cnt++;
       }
      }

     } else if ($stringNum==($totalStrings-1))
     {
      $acceptible=true;
      // echo "maxMuted: $maxMuted<br>";
      if(substr_count($newFretNumsSoFar,"-1")>$maxMuted)
      {
       $acceptible=false;
      } 
      //else 
      //echo "maxMuted: $maxMuted ".substr_count($newFretNumsSoFar,"-1")."<br>";
      
      if (!checkFretSpan($newFretNumsSoFar,$fretSpan))
      {
        $acceptible=false;
        //echo "$newFretNumsSoFar rejected by checkFretSpan<br>";
      }
      if(!includesEveryNote($newFretNumsSoFar,$strings,$spelling,$startNote) )
      {
       $acceptible=false;
       //echo "$newFretNumsSoFar rejected by includesEveryNote<br>";
      }
      if($acceptible &&($fretNum!=-1||($fretNum==-1&&$orig)))
      {
       //echo "$newFretNumsSoFar deemed acceptible, cnt: $cnt<br>"; 
       $chordPosArray[$cnt]=$newFretNumsSoFar;
       $cnt++;
      }
     }
    }
    $orig=false;   
   }
   }
  }
 }
// echo "<br>";
 return $chordPosArray;
}

function drawChordPosition($chordPosition,$strings)

{
 $lowestFret=getLowestFret($chordPosition);
 $highestFret=getHighestFret($chordPosition);
 $stringArray=explode(",", $strings);
 $chordPositionArray=explode(",", $chordPosition);
 
 $diff=$highestFret-$lowestFret;
 if($diff<5 && $lowestFret>1)
 { 	
  $startFret=$lowestFret-(5-$diff);
 } else
  $startFret=$lowestFret;
 
 if($startFret<1) $startFret=1;
 $endFret=$startFret+5;
 $imageSize=8;
 $notes=chordPo2Notes($chordPosition, "C", $strings);
 echo "<img height=$imageSize width=$imageSize src=\"images".chr(47)."lowerLine.png\">";  
 foreach (explode(",",$notes) as $noteNum => $theNote)
 {
   echo "<img height=$imageSize width=$imageSize src=\"images".chr(47).$theNote.".png\">";  
 }
 echo "<br>";
 for($currentFret=$startFret;$currentFret<=$endFret;$currentFret++)
 {
   echo "<img height=$imageSize width=$imageSize src=\"images".chr(47).$currentFret.".png\">";
   foreach ($stringArray as $stringNum => $theString)
   {
     if($chordPositionArray[$stringNum]==$currentFret)
     {
      echo "<img height=$imageSize width=$imageSize src=\"images".chr(47)."openCircle.png\">";  
     }
     else
     {
      echo "<img height=$imageSize width=$imageSize src=\"images".chr(47)."spacer.png\">";  
     }
   }     
   echo "<br>";
 }
 echo "<img height=$imageSize width=$imageSize src=\"images".chr(47)."upperSpacer.png\">";  
 foreach ($chordPositionArray as $chordPositionNum => $theChordPosition)
 {
   echo "<img height=$imageSize width=$imageSize src=\"images".chr(47)."u".$theChordPosition.".png\">";  
 }
 echo "<br>";

}

function showChordList($chordArray)
{
 $noteAndChordArray="";
 $noteAndChordNum=0;
 
 if(is_array($chordArray))
 foreach ($chordArray as $chordNum => $chord)
 {
  if($chord['booPrefer']==1||1==1)
  {
   $names = "";
   if($chord['txtName'] <> $chord['txtCode'])
   {
    $names=$chord['txtName'];
    if($chord['txtAltNames'] <> "")
     $names.=", ";
   }
   $names.=$chord['txtAltNames']; 

   $modeArray=getModeArray($chord['txtSpelling']);

   $found = false;
   $noteAndChordCode=$chord['startNote']." ".$chord['txtCode'];
   if(is_array($noteAndChordArray))
   {
    foreach($noteAndChordArray as $noteAndChordToCheckNum => $noteAndChordToCheck)
    {
     if($noteAndChordToCheck==$noteAndChordCode)
      $found=true;
    }
   }
  
   if(!$found) 
   {
    $noteAndChordArray[$noteAndChordNum++]=$noteAndChordCode;
    $completeChordName = $noteAndChordCode." ";

    foreach ($modeArray as $modeNum => $thisMode) 
    {
     $modeNote=num2note(note2num($startNote)+sc2num($thisMode[0]),$referenceNote);
     $outMSc = $thisMode[1];
     $inversionChordArray=getScaleArrayFromSpelling($outMSc);
     if(is_array($inversionChordArray))
     {
      foreach ($inversionChordArray as $inversionChordNum => $inversionChord) 
      {
       $modeNoteAndChord=$modeNote." ".$inversionChord['txtCode'];
       $found=false;
       foreach($noteAndChordArray as $noteAndChordToCheckNum => $noteAndChordToCheck)
       {
        if($noteAndChordToCheck==$modeNoteAndChord)
         $found=true;
       }
       if(!$found)
       {
        $noteAndChordArray[$noteAndChordNum++]=$modeNoteAndChord;
        $completeChordName .= " / $modeNoteAndChord";
        echo "note: ".$chord['startNote']."<br>";
        echo "spelling: ".$chord['txtSpelling']."<br>";
        echo "names: $names<br>";
        echo "completeChordName: $completeChordName<br>";   
       }                   	
      }
     }
    }
   }
  }
 }
}

//--------------------------------------------------displayFretBoard
function displayFretBoard($strings,$totalFrets,$nutPos,$spelling, $startNote, $showSc, $chordPo, $fretSpan)
{
$colors[1]="Black";
$colors[2]="Blue";
$colors[3]="BlueViolet";
$colors[4]="Brown";
$colors[5]="BurlyWood";
$colors[6]="CadetBlue";
$colors[7]="Chartreuse";
$colors[8]="Chocolate";
$colors[9]="Coral";
$colors[10]="CornflowerBlue";
$colors[11]="Crimson";
$colors[12]="Cyan";
$colors[13]="DarkBlue";
$colors[14]="DarkCyan";
$colors[15]="DarkGoldenRod";
$colors[16]="DarkGray";
$colors[17]="DarkGreen";
$colors[18]="DarkKhaki";
$colors[19]="DarkMagenta";
$colors[20]="DarkOliveGreen";
$colors[21]="Darkorange";
$colors[22]="DarkOrchid";
$colors[23]="DarkRed";
$colors[24]="DarkSalmon";
$colors[25]="DarkSeaGreen";
$colors[26]="DarkSlateBlue";
$colors[27]="DarkSlateGray";
$colors[28]="DarkTurquoise";
$colors[29]="DarkViolet";
$colors[30]="DeepPink";
$colors[31]="DeepSkyBlue";
$colors[32]="DimGray";
$colors[33]="DodgerBlue";
$colors[34]="Feldspar";
$colors[35]="FireBrick";
$colors[36]="ForestGreen";
$colors[37]="Fuchsia";
$colors[38]="Gainsboro";
$colors[39]="Gold";
$colors[40]="GoldenRod";
$colors[41]="Gray";
$colors[42]="Green";
$colors[43]="GreenYellow";
$colors[44]="HotPink";
$colors[45]="IndianRed";
/*
"Indigo",
"Ivory",
"Khaki",
"Lavender",
"LavenderBlush",
"LawnGreen",
"LemonChiffon",
"LightBlue",
"LightCoral",
"LightCyan",
"LightGoldenRodYellow",
"LightGrey",
"LightGreen",
"LightPink",
"LightSalmon",�
"LightSeaGreen",�
"LightSkyBlue",
"LightSlateBlue",�
"LightSlateGray",
"LightSteelBlue",
"LightYellow",
"Lime",
"LimeGreen",
"Linen",
"Magenta",�
"Maroon",
"MediumAquaMarine",
"MediumBlue",
"MediumOrchid",�
"MediumPurple",
"MediumSeaGreen",�
"MediumSlateBlue",
"MediumSpringGreen",�
"MediumTurquoise",
"MediumVioletRed",
"MidnightBlue",
"MintCream",
"MistyRose",
"Moccasin",
"NavajoWhite",
"Navy",
"OldLace",
"Olive",
"OliveDrab",
"Orange",
"OrangeRed",
"Orchid",
"PaleGoldenRod",
"PaleGreen",
"PaleTurquoise",
"PaleVioletRed",
"PapayaWhip",
"PeachPuff",
"Peru",
"Pink",
"Plum",
"PowderBlue",
"Purple",
"Red",
"RosyBrown",
"RoyalBlue",
"SaddleBrown",�
"Salmon",
"SandyBrown",
"SeaGreen",
"SeaShell",
"Sienna",
"Silver",
"SkyBlue",
"SlateBlue",�
"SlateGray",
"Snow",�
"SpringGreen",
"SteelBlue",
"Tan",
"Teal",
"Thistle",
"Tomato",
"Turquoise",
"Violet",
"VioletRed",
"Wheat",
"WhiteSmoke",
"Yellow",
"YellowGreen");
*/
 
 $spellingArray=explode(",", "1,".$spelling);
 $startNum = note2num($startNote);
 $stringArray=explode(",", $strings);
 $chordPoArray=explode(",", $chordPo);

 $numNotes = count($spellingArray);
 $numStrings = count($stringArray);

 if($numNotes<=$numStrings)
  $cps = discoverChordPos($strings,$totalFrets, $fretSpan, $nutPos, $spelling,$startNote);
 else
  $cps="";
  
 echo "<table border=1>";

  for( $fretNum=0; $fretNum<=$totalFrets; $fretNum++ )
  {
   echo "<tr>";
   foreach ($stringArray as $stringNum => $string)
   {
    if($fretNum%12==5  || $fretNum%12 ==7 
             || $fretNum%12 ==10 || $fretNum%12 ==0)
     $bgcolor="lightgrey";
          else
     $bgcolor="white";

    echo "<td bgcolor=\"$bgcolor\">";
    $currentNum = note2num($string)+$fretNum;
    $currentNote=num2note($currentNum, $startNote);
    $startNoteNum = note2num($startNote);
    $sc = num2sc(($currentNum + 12 - $startNoteNum)%12);

    $matchesSpelling =in_array($sc, $spellingArray); 

/*
<script type="javascript">
 <!--
 function checkBoxes()
 {
  a=1;
 }
 //-->
</script>
*/
?>
<?php
    if($matchesSpelling) 
    {
     echo "<input name=\"cb$stringNum.$fretNum\" type=\"checkbox\" checked>";
     echo "$currentNote - $sc";
     if(is_array($cps))
     {
      $outs="";
      foreach ($cps as $cpNum => $cp)
      {
       $cpArray = explode(",", $cp);
       if($fretNum==$cpArray[$stringNum])
       { 
       	if($outs=="") $outs .= " {";
       	 $outs .= " <span><font color=" . $colors[$cpNum].">$cpNum</font></span>";
       }
      }
      if($outs!="") $outs .= "}";
      echo "<font size=\"-2\"><b>$outs</b></font>";
     }
    }
    else
     echo "<input name=\"cb$stringNum.$fretNum\" type=\"checkbox\">";    
     
    echo "</td>";
   }
   echo "</tr>";
  }

/*
 if($chordPo != "") 
 {
//  echo "here<br>";
  foreach (explode(",", $strings) as $stringNum => $string) 
  {
   for($fretNum=($nutOnLeft?0:$totalFrets);
    $nutOnLeft?$fretNum<=$totalFrets:$fretNum>=0; 
    $nutOnLeft?$fretNum++:$fretNum--)
   {
    if($fretNum%12==5  || $fretNum%12 ==7 
             || $fretNum%12 ==10 || $fretNum%12 ==0)
     $img="lightgray";
          else
     $img="white";
    $currentNum = note2num($string)+$fretNum;
    if($fretNum==$chordPoArray[$stringNum])
     $img="black";

//    echo "$totalFrets / $fretNum / $img <br>";
    echo "<img src=\"$img.GIF\" width=\"4\" height=\"4\" border=\"0\">";
    if(($nutOnLeft && $fretNum==$totalFrets) || (!$nutOnLeft && $fretNum==0))
     echo "<br>";
   }
  }
 }
*/
}
 
?>
