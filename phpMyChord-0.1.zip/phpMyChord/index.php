<!DOCTYPE HTML PUBLIC "-//W3C//DTD HTML 4.0 Transitional//EN">
<HTML>
<HEAD>
	<META HTTP-EQUIV="CONTENT-TYPE" CONTENT="text/html; charset=windows-1252">
	<TITLE></TITLE>
	<META NAME="GENERATOR" CONTENT="OpenOffice.org 1.1.4  (Win32)">
	<META NAME="CREATED" CONTENT="20050104;12354977">
	<META NAME="CHANGED" CONTENT="20050104;17043064">
	<STYLE>
	<!--
		@page { size: 8.5in 11in }
	-->
	</STYLE>
</HEAD>

<BODY LANG="en-US" DIR="LTR">
<h1>phpMyChord</h1>
<P>Open Source Musical Tone Visualization Tools</P>
<P>Gnu Public Liscense</P>

<p>
<a href="dicts<?php echo chr(47);?>showSciPositions.php">Demonstration</a> that shows
how you can use phpMyChord to output learning sheets for the chords
of the song that your band is trying to learn.  This demonstration
gives the chords for ukulele, bass, and guitar.
</p>

<P>PhpMyChord Aims to provide:</P>
<UL>
	<LI><P>Mathematically complete Sci (Scale, Chord, Interval)
	Database, informed by international and historical culture of 12
	tone music.</P>
	<LI><P>Custom chord and scale dictionaries for any instrument</P>
	<LI><P>Contemplative diagrams illuminating tonal sacred geometries</P>

</UL>
<P>Required Technologies:</P>
<UL>
	<LI><P>LampServer or WampServer (or equivalent). Therefore, Windows,
	Mac OS/X, and Linux compatible.</P>
</UL>
<P>Installation Instructions:</P>
<P>Download zip file
</P>
<P>Extract folder into www directory, e.g. C:\wamp\www</P>
<P>Using phpMyAdmin, run the .sql file in the MySQL database you will
be using for this project.</P>
<P>Edit config.php to match your database name, user name, and
password.</P>

<P>phpMyChord project coordinator is Benjamin Kinsey. You can get in
touch with me at bk@bksy.com</P>
<P>I would love help so please volunteer! It is fun.</P>
<P>Definitions:</P>
<P>Note: C, Db, D, E, F, Gb, G, Ab, A, Bb, or B (flatted form is
preferred since it simplifies the Base 12 operations).</P>
<P>Sci: Scale, Chord or Interval. Consists of Note and SciCode
separated by space character. e.g. &ldquo;C -&rdquo; is C Minor
Chord.</P>
<P>SciDegree: 1 (smallest), b2, 2, b3, 3, 4, b5, 5, b6, 6, b7, or 7
(highest). Sometimes called scale degrees. 
</P>
<P>SciCode: preferred code of SciType. e.g. &ldquo;-&rdquo; is the
SciCode of SciName &ldquo;Minor Chord&rdquo; in my convention</P>

<P>SciName: preferred name of SciType. My choice is the default
SciName.</P>
<P>SciSpelling: Comma delimited SciDegrees, omitting the 1, ordered
from smallest to highest. e.g. b3,5 is the SciSpelling for SciName
&ldquo;Minor Chord&rdquo;.</P>
<P>SciMode: new SciType derived from a given SciType starting on a
different SciDegree.</P>
<P>Mode: new Sci derived from a given Sci starting on a different
Note.</P>
<P>SciIntervalForm: A SciType written in terms of intervals.  e.g.
&ldquo;-&rdquo; is &ldquo;d3 a3&rdquo;</P>
<P>SciNumericIntervalForm: like the SciIntervalForm but written with
the numeric equivalents e.g. &ldquo;3 4&rdquo; as follows:</P>

<TABLE WIDTH=368 BORDER=1 CELLPADDING=4 CELLSPACING=3>
	<COL WIDTH=119>
	<COL WIDTH=70>
	<COL WIDTH=141>
	<THEAD>
		<TR VALIGN=TOP>
			<TH WIDTH=119>
				<P>Interval Name</P>
			</TH>

			<TH WIDTH=70>
				<P>SciCode</P>
			</TH>
			<TH WIDTH=141>
				<P>Numeric Equivalent</P>
			</TH>
		</TR>
	</THEAD>

	<TBODY>
		<TR>
			<TD WIDTH=119 VALIGN=TOP>
				<P>Minor Second</P>
			</TD>
			<TD WIDTH=70 VALIGN=TOP>
				<P>d2</P>
			</TD>

			<TD WIDTH=141 VALIGN=BOTTOM SDVAL="1" SDNUM="1033;">
				<P ALIGN=LEFT>1</P>
			</TD>
		</TR>
		<TR>
			<TD WIDTH=119 VALIGN=TOP>
				<P>Major Second</P>
			</TD>

			<TD WIDTH=70 VALIGN=TOP>
				<P>n2</P>
			</TD>
			<TD WIDTH=141 VALIGN=BOTTOM SDVAL="2" SDNUM="1033;">
				<P ALIGN=LEFT>2</P>
			</TD>
		</TR>
		<TR>

			<TD WIDTH=119 VALIGN=TOP>
				<P>Minor Third</P>
			</TD>
			<TD WIDTH=70 VALIGN=TOP>
				<P>d3</P>
			</TD>
			<TD WIDTH=141 VALIGN=BOTTOM SDVAL="3" SDNUM="1033;">
				<P ALIGN=LEFT>3</P>

			</TD>
		</TR>
		<TR>
			<TD WIDTH=119 VALIGN=TOP>
				<P>Major Third</P>
			</TD>
			<TD WIDTH=70 VALIGN=TOP>
				<P>n3</P>

			</TD>
			<TD WIDTH=141 VALIGN=BOTTOM SDVAL="4" SDNUM="1033;">
				<P ALIGN=LEFT>4</P>
			</TD>
		</TR>
		<TR>
			<TD WIDTH=119 VALIGN=TOP>
				<P>Perfect Fourth</P>

			</TD>
			<TD WIDTH=70 VALIGN=TOP>
				<P>P4</P>
			</TD>
			<TD WIDTH=141 VALIGN=BOTTOM SDVAL="5" SDNUM="1033;">
				<P ALIGN=LEFT>5</P>
			</TD>
		</TR>

		<TR>
			<TD WIDTH=119 VALIGN=TOP>
				<P>Tritone</P>
			</TD>
			<TD WIDTH=70 VALIGN=TOP>
				<P>T</P>
			</TD>
			<TD WIDTH=141 VALIGN=BOTTOM SDVAL="6" SDNUM="1033;">

				<P ALIGN=LEFT>6</P>
			</TD>
		</TR>
		<TR>
			<TD WIDTH=119 VALIGN=TOP>
				<P>Perfect Fifth</P>
			</TD>
			<TD WIDTH=70 VALIGN=TOP>

				<P>P5</P>
			</TD>
			<TD WIDTH=141 VALIGN=BOTTOM SDVAL="7" SDNUM="1033;">
				<P ALIGN=LEFT>7</P>
			</TD>
		</TR>
		<TR>
			<TD WIDTH=119 VALIGN=TOP>

				<P>Minor Sixth</P>
			</TD>
			<TD WIDTH=70 VALIGN=TOP>
				<P>d6</P>
			</TD>
			<TD WIDTH=141 VALIGN=BOTTOM SDVAL="8" SDNUM="1033;">
				<P ALIGN=LEFT>8</P>

			</TD>
		</TR>
		<TR>
			<TD WIDTH=119 VALIGN=TOP>
				<P>Major Sixth</P>
			</TD>
			<TD WIDTH=70 VALIGN=TOP>
				<P>n6</P>

			</TD>
			<TD WIDTH=141 VALIGN=BOTTOM SDVAL="9" SDNUM="1033;">
				<P ALIGN=LEFT>9</P>
			</TD>
		</TR>
		<TR>
			<TD WIDTH=119 VALIGN=TOP>
				<P>Minor Seventh</P>

			</TD>
			<TD WIDTH=70 VALIGN=TOP>
				<P>d7</P>
			</TD>
			<TD WIDTH=141 VALIGN=BOTTOM SDVAL="10" SDNUM="1033;">
				<P ALIGN=LEFT>10</P>
			</TD>
		</TR>

		<TR>
			<TD WIDTH=119 VALIGN=TOP>
				<P>Major Seventh</P>
			</TD>
			<TD WIDTH=70 VALIGN=TOP>
				<P>n7</P>
			</TD>
			<TD WIDTH=141 VALIGN=BOTTOM SDVAL="11" SDNUM="1033;">

				<P ALIGN=LEFT>11</P>
			</TD>
		</TR>
	</TBODY>
</TABLE>
<P><BR><BR>
</P>
<P>SciSequence: comma delimited Sci list. e.g. &ldquo;C -,D M,A 7&rdquo;.
 Can be transformed into Sci using sciSequence2sci() function.</P>
<P>Tuning: comma delimited list of notes of a stringed instrument. 
e.g. ukulele is &ldquo;G,C,E,A&rdquo;</P>

<P>StringPosition: numeric representation the fret of a string on a
stringed instrument.  &ldquo;0&rdquo; means open string.  &ldquo;x&rdquo;
means muted string.</P>
<P>SciPosition: a comma delimited list of StringPositions
representing a fingering position of a particular chord for a
particular tuning.  SciPosition &ldquo;0,0,0,3&rdquo; is Sci &ldquo;C
M&rdquo; for tuning &ldquo;G,C,E,A&rdquo;.  SciPosition2sci
transforms a SciPosition to a Sci.  

</P>
<P>NoteCircleOfFifths: Notes arranged in a circle starting with C and
incrementing by a Perfect Fifth interval (7 SciDegrees). C, G, D, A,
E, B, Gb, Db, Ab, Eb, Bb, and F. Associated with the Zodiac with C as
Aries.</P>
<P>SciDegreeCircleOfFifths: 1, 5, 2, 6, 3, 7, b5, b2, b6, b3, b7, and
4. Associated with the solar system bodies: Sun (1), Mercury (5),
Venus (2), Moon (6), Mars (3), Jupiter (7), Saturn (b5), Uranus (b2),
Neptune (b6), Pluto (b3), Sedna (b7) and Quaoar (4).Mode: Sci derived
from another Sci starting on a different Note.</P>
<TABLE WIDTH=100% BORDER=1 CELLPADDING=2 CELLSPACING=3>
	<COL WIDTH=30*>
	<COL WIDTH=54*>
	<COL WIDTH=44*>
	<COL WIDTH=35*>
	<COL WIDTH=58*>
	<COL WIDTH=35*>

	<TR VALIGN=TOP>
		<TH WIDTH=12%>
			<P>Note</P>
		</TH>
		<TH WIDTH=21%>
			<P>Western Zodiac</P>
		</TH>
		<TD ROWSPAN=13 WIDTH=17%></TD>

		<TH WIDTH=14%>
			<P>SciDegree</P>
		</TH>
		<TH WIDTH=23%>
			<P>Solar System Object</P>
		</TH>
		<TD ROWSPAN=13 WIDTH=14%></TD>
	</TR>

	<TR>
		<TD WIDTH=12% VALIGN=TOP>
			<P>C</P>
		</TD>
		<TD WIDTH=21% VALIGN=TOP>
			<P>Aries</P>
		</TD>
		<TD WIDTH=14% VALIGN=BOTTOM SDVAL="1" SDNUM="1033;">

			<P ALIGN=LEFT>1</P>
		</TD>
		<TD WIDTH=23% VALIGN=TOP>
			<P>Sun</P>
		</TD>
	</TR>
	<TR>
		<TD WIDTH=12% VALIGN=TOP>

			<P>G</P>
		</TD>
		<TD WIDTH=21% VALIGN=TOP>
			<P>Taurus</P>
		</TD>
		<TD WIDTH=14% VALIGN=BOTTOM SDVAL="5" SDNUM="1033;">
			<P ALIGN=LEFT>5</P>

		</TD>
		<TD WIDTH=23% VALIGN=TOP>
			<P>Mercury</P>
		</TD>
	</TR>
	<TR>
		<TD WIDTH=12% VALIGN=TOP>
			<P>D</P>

		</TD>
		<TD WIDTH=21% VALIGN=TOP>
			<P>Gemini</P>
		</TD>
		<TD WIDTH=14% VALIGN=BOTTOM SDVAL="2" SDNUM="1033;">
			<P ALIGN=LEFT>2</P>
		</TD>
		<TD WIDTH=23% VALIGN=TOP>

			<P>Venus</P>
		</TD>
	</TR>
	<TR>
		<TD WIDTH=12% VALIGN=TOP>
			<P>A</P>
		</TD>
		<TD WIDTH=21% VALIGN=TOP>

			<P>Cancer</P>
		</TD>
		<TD WIDTH=14% VALIGN=BOTTOM SDVAL="6" SDNUM="1033;">
			<P ALIGN=LEFT>6</P>
		</TD>
		<TD WIDTH=23% VALIGN=TOP>
			<P>Moon</P>

		</TD>
	</TR>
	<TR>
		<TD WIDTH=12% VALIGN=TOP>
			<P>E</P>
		</TD>
		<TD WIDTH=21% VALIGN=TOP>
			<P>Leo</P>

		</TD>
		<TD WIDTH=14% VALIGN=BOTTOM SDVAL="3" SDNUM="1033;">
			<P ALIGN=LEFT>3</P>
		</TD>
		<TD WIDTH=23% VALIGN=TOP>
			<P>Mars</P>
		</TD>
	</TR>

	<TR>
		<TD WIDTH=12% VALIGN=TOP>
			<P>B</P>
		</TD>
		<TD WIDTH=21% VALIGN=TOP>
			<P>Virgo</P>
		</TD>
		<TD WIDTH=14% VALIGN=BOTTOM SDVAL="7" SDNUM="1033;">

			<P ALIGN=LEFT>7</P>
		</TD>
		<TD WIDTH=23% VALIGN=TOP>
			<P>Jupiter</P>
		</TD>
	</TR>
	<TR VALIGN=TOP>
		<TD WIDTH=12%>

			<P>Gb</P>
		</TD>
		<TD WIDTH=21%>
			<P>Libra</P>
		</TD>
		<TD WIDTH=14%>
			<P ALIGN=LEFT>b5</P>

		</TD>
		<TD WIDTH=23%>
			<P>Saturn</P>
		</TD>
	</TR>
	<TR VALIGN=TOP>
		<TD WIDTH=12%>
			<P>Db</P>

		</TD>
		<TD WIDTH=21%>
			<P>Scorpio</P>
		</TD>
		<TD WIDTH=14%>
			<P ALIGN=LEFT>b2</P>
		</TD>
		<TD WIDTH=23%>

			<P>Uranus</P>
		</TD>
	</TR>
	<TR VALIGN=TOP>
		<TD WIDTH=12%>
			<P>Ab</P>
		</TD>
		<TD WIDTH=21%>

			<P>Saggitarius</P>
		</TD>
		<TD WIDTH=14%>
			<P ALIGN=LEFT>b6</P>
		</TD>
		<TD WIDTH=23%>
			<P>Neptune</P>

		</TD>
	</TR>
	<TR VALIGN=TOP>
		<TD WIDTH=12%>
			<P>Eb</P>
		</TD>
		<TD WIDTH=21%>
			<P>Capricorn</P>

		</TD>
		<TD WIDTH=14%>
			<P ALIGN=LEFT>b3</P>
		</TD>
		<TD WIDTH=23%>
			<P>Pluto</P>
		</TD>
	</TR>

	<TR VALIGN=TOP>
		<TD WIDTH=12%>
			<P>Bb</P>
		</TD>
		<TD WIDTH=21%>
			<P>Aquarius</P>
		</TD>
		<TD WIDTH=14%>

			<P ALIGN=LEFT>b7</P>
		</TD>
		<TD WIDTH=23%>
			<P>Sedna</P>
		</TD>
	</TR>
	<TR>
		<TD WIDTH=12% VALIGN=TOP>

			<P>F</P>
		</TD>
		<TD WIDTH=21% VALIGN=TOP>
			<P>Pisces</P>
		</TD>
		<TD WIDTH=14% VALIGN=BOTTOM SDVAL="4" SDNUM="1033;">
			<P ALIGN=LEFT>4</P>

		</TD>
		<TD WIDTH=23% VALIGN=TOP>
			<P>Quaoar</P>
		</TD>
	</TR>
</TABLE>
<P><BR><BR>
</P>
</BODY>
</HTML>